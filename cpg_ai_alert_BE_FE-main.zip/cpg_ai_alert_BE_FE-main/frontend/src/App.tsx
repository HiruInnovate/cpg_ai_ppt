import { Suspense } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./contexts/AuthContext";
import { Toaster } from "./components/ui/toaster";
import ProtectedRoute from "./components/ProtectedRoute";
import AppLayout from "./components/layout/AppLayout";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import DataIntegrator from "./pages/DataIntegrator";
import RootCauseAnalysis from "./pages/RootCauseAnalysis";
import ImpactAnalysis from "./pages/ImpactAnalysis";
import AIChat from "./pages/AIChat";
import VisionAnalyzer from "./pages/VisionAnalyzer";

function App() {
  return (
    <AuthProvider>
      <Suspense fallback={
        <div className="min-h-screen flex items-center justify-center bg-slate-50">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <p className="text-slate-600">Loading...</p>
          </div>
        </div>
      }>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          
          <Route element={
            <ProtectedRoute>
              <AppLayout />
            </ProtectedRoute>
          }>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/data-integrator" element={
              <ProtectedRoute requiredRole="admin">
                <DataIntegrator />
              </ProtectedRoute>
            } />
            <Route path="/rca" element={<RootCauseAnalysis />} />
            <Route path="/impact" element={<ImpactAnalysis />} />
            <Route path="/chat" element={<AIChat />} />
            <Route path="/vision" element={<VisionAnalyzer />} />
          </Route>
        </Routes>
        <Toaster />
      </Suspense>
    </AuthProvider>
  );
}

export default App;
