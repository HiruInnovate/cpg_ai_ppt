export type UserRole = 'admin' | 'user';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
}

export interface Alert {
  id: string;
  title: string;
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  type: string;
  date: string;
  status: 'active' | 'resolved' | 'investigating';
  location?: string;
  affectedProducts?: string[];
}



export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  meta?: {
    action?: string;
    status?: string;
  };
}

export interface RCAAgentStep {
  step: number;
  tool: string;
  tool_input: string;
  observation: string;
}

export interface RCARecommendation {
  id: string;
  action: string;
  eta_hours: number;
  confidence_est: number;
}

export interface RCACause {
  label: string;
  explanation: string;
}

export interface RCAFinalJson {
  causes: RCACause[];
  confidence: number;
  summary: string;
  recommendations: RCARecommendation[];
  evidence: string[];
}

export interface RCAResponse {
  status: 'success' | 'error';
  rca: {
    steps: RCAAgentStep[];
    final_answer: string;
    final_json: RCAFinalJson;
    logs: string;
  };
}

export interface RCAResult {
  alertId: string;
  summary: string;
  causes: RCACause[];
  recommendations: RCARecommendation[];
  evidence: string[];
  confidence: number;
  logs: string;
  steps: RCAAgentStep[];
}

export interface RCACause {
  label: string;
  explanation: string;
}

export interface RCARecommendation {
  id: string;
  action: string;
  eta_hours: number;
  confidence_est: number;
}

export interface RCAData {
  causes: RCACause[];
  confidence: number;
  summary: string;
  recommendations: RCARecommendation[];
  evidence: string[];
}

export interface ImpactItem {
  sku: string;
  region: string;
  at_risk_units: number;
  unfulfilled_units: number;
  lost_sales: number;
  sla_penalty: number;
  expedite_cost: number;
  notes: string;
}

export interface ImpactTotals {
  lost_sales: number;
  sla_penalty: number;
  expedite_cost: number;
  overall: number;
}

export interface ImpactData {
  impact_summary: string;
  delay_hours: number;
  items: ImpactItem[];
  total: ImpactTotals;
  assumptions: string[];
  confidence: number;
}

export interface TraceStep {
  step: number;
  tool: string;
  tool_input: string;
  observation: string;
}

export interface AgentTrace {
  agent: string;
  steps: TraceStep[];
}

export interface ImpactResult {
  alert_id: string;
  rca: RCAData;
  impact: ImpactData;
  traces: AgentTrace[];
  logs: string[];
}
