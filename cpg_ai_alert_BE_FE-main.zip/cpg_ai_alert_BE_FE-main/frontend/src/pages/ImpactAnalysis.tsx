import React, { useState, useEffect } from "react";
import { Alert, ImpactResult } from "@/types";
import { alertsApi, impactApi } from "@/lib/api";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  TrendingUp,
  Loader2,
  Download,
  CheckCircle,
  AlertCircle,
  ChevronDown,
  ChevronUp,
  Bot,
  Activity,
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import jsPDF from "jspdf";

const ImpactAnalysis: React.FC = () => {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null);
  const [isLoadingAlerts, setIsLoadingAlerts] = useState(true);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<ImpactResult | null>(
    null
  );
  const [analysisStatus, setAnalysisStatus] = useState("");
  const [isAlertSectionOpen, setIsAlertSectionOpen] = useState(true);
  const [agentPhase, setAgentPhase] = useState<"idle" | "rca" | "impact">("idle");
  const { toast } = useToast();

  useEffect(() => {
    loadAlerts();
  }, []);

  const loadAlerts = async () => {
    setIsLoadingAlerts(true);
    try {
      const data = await alertsApi.getAlerts();
      setAlerts(data.filter((a) => a.status !== "resolved"));
    } catch {
      toast({
        title: "Error",
        description: "Failed to load alerts",
        variant: "destructive",
      });
    } finally {
      setIsLoadingAlerts(false);
    }
  };

  const runAnalysis = async () => {
    if (!selectedAlert) return;
    setIsAnalyzing(true);
    setAnalysisResult(null);
    setAgentPhase("rca");
    setAnalysisStatus("Initializing RCA + Impact analysis...");

    try {
      // Simulate RCA phase first
      setTimeout(() => {
        setAnalysisStatus("🧠 RCA Agent is analyzing disruption patterns...");
        setAgentPhase("rca");
      }, 2500);

      // Then transition to Impact Agent phase
      setTimeout(() => {
        setAnalysisStatus("📊 Impact Agent is evaluating financial losses...");
        setAgentPhase("impact");
      }, 3500);

      // Await backend result
      const result = await impactApi.runAnalysis(selectedAlert);

      setAnalysisResult(result);
      setAgentPhase("idle");

      toast({
        title: "Analysis Complete",
        description: "RCA + Impact analysis completed successfully",
      });
    } catch {
      toast({
        title: "Analysis Failed",
        description: "Error running impact analysis",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
      setAnalysisStatus("");
      setAgentPhase("idle");
    }
  };

  const downloadReport = () => {
    if (!analysisResult || !selectedAlert) return;

    const doc = new jsPDF();
    let y = 10;
    const marginLeft = 10;

    doc.setFontSize(14);
    doc.text("RCA + Impact Analysis Report", marginLeft, y);
    y += 10;

    doc.setFontSize(11);
    doc.text(`Alert: ${selectedAlert.title}`, marginLeft, y);
    y += 8;
    doc.text(`Date: ${new Date().toLocaleString()}`, marginLeft, y);
    y += 10;
    doc.text("-----------------------------------------", marginLeft, y);
    y += 10;

    // RCA Summary
    doc.setFontSize(12);
    doc.text("Root Cause Analysis Summary:", marginLeft, y);
    y += 8;
    doc.setFontSize(10);
    doc.text(
      doc.splitTextToSize(analysisResult.rca.summary, 180),
      marginLeft,
      y
    );
    y += 16;

    doc.setFontSize(11);
    doc.text("Causes Identified:", marginLeft, y);
    y += 8;
    analysisResult.rca.causes.forEach((cause, i) => {
      const lines = doc.splitTextToSize(
        `${i + 1}. ${cause.label}: ${cause.explanation}`,
        180
      );
      doc.text(lines, marginLeft, y);
      y += lines.length * 6 + 2;
    });
    y += 8;

    // Impact Summary
    doc.setFontSize(12);
    doc.text("Impact Summary:", marginLeft, y);
    y += 8;
    doc.setFontSize(10);
    doc.text(
      doc.splitTextToSize(analysisResult.impact.impact_summary, 180),
      marginLeft,
      y
    );
    y += 16;

    // Financial Totals
    doc.setFontSize(11);
    doc.text("Financial Impact:", marginLeft, y);
    y += 8;
    doc.setFontSize(10);
    doc.text(
      `Lost Sales: ₹${analysisResult.impact.total.lost_sales.toLocaleString()}`,
      marginLeft,
      y
    );
    y += 6;
    doc.text(
      `SLA Penalty: ₹${analysisResult.impact.total.sla_penalty.toLocaleString()}`,
      marginLeft,
      y
    );
    y += 6;
    doc.text(
      `Overall Impact: ₹${analysisResult.impact.total.overall.toLocaleString()}`,
      marginLeft,
      y
    );
    y += 10;

    // Assumptions
    doc.setFontSize(11);
    doc.text("Assumptions:", marginLeft, y);
    y += 8;
    analysisResult.impact.assumptions.forEach((a, i) => {
      const lines = doc.splitTextToSize(`${i + 1}. ${a}`, 180);
      doc.text(lines, marginLeft, y);
      y += lines.length * 6;
    });

    doc.save(`Impact_Report_${selectedAlert.id}.pdf`);
    toast({
      title: "Report Downloaded",
      description: "PDF report with RCA + Impact details has been saved.",
    });
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-red-100 text-red-800 border-red-200";
      case "high":
        return "bg-orange-100 text-orange-800 border-orange-200";
      case "medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "low":
        return "bg-blue-100 text-blue-800 border-blue-200";
      default:
        return "bg-slate-100 text-slate-800 border-slate-200";
    }
  };

  return (
    <div className="p-6 space-y-6 bg-slate-50 min-h-full">
      <h1 className="text-3xl font-bold text-slate-900">Impact Analysis</h1>
      <p className="text-slate-600">
        Assess financial, operational, and reputational impact of disruptions.
      </p>

      {/* Alert Selection Collapsible */}
      <Card className="border-slate-200 shadow-sm">
        <CardHeader
          className="flex flex-row justify-between items-center cursor-pointer"
          onClick={() => setIsAlertSectionOpen(!isAlertSectionOpen)}
        >
          <div>
            <CardTitle>Select Alert</CardTitle>
            <CardDescription>Choose an alert to run RCA + Impact</CardDescription>
          </div>
          {isAlertSectionOpen ? (
            <ChevronUp className="w-5 h-5 text-slate-600" />
          ) : (
            <ChevronDown className="w-5 h-5 text-slate-600" />
          )}
        </CardHeader>

        {isAlertSectionOpen && (
          <CardContent>
            <div className="space-y-3 max-h-[400px] overflow-y-auto">
              {isLoadingAlerts ? (
                Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-24 w-full" />
                ))
              ) : alerts.length === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  <AlertCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No active alerts available</p>
                </div>
              ) : (
                alerts.map((alert) => (
                  <Card
                    key={alert.id}
                    className={`cursor-pointer transition-all border-2 ${
                      selectedAlert?.id === alert.id
                        ? "border-blue-500 bg-blue-50"
                        : "border-slate-200 hover:border-slate-300 hover:shadow-md"
                    }`}
                    onClick={() => setSelectedAlert(alert)}
                  >
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-semibold text-slate-900">
                            {alert.title}
                          </h3>
                          <p className="text-sm text-slate-600 mt-1">
                            {alert.description}
                          </p>
                          <div className="flex flex-wrap gap-2 mt-2">
                            <Badge
                              className={getSeverityColor(alert.severity)}
                              variant="outline"
                            >
                              {alert.severity}
                            </Badge>
                            <Badge variant="outline">{alert.type}</Badge>
                          </div>
                        </div>
                        {selectedAlert?.id === alert.id && (
                          <CheckCircle className="w-5 h-5 text-blue-600" />
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </CardContent>
        )}
      </Card>

      {/* Analysis Results */}
      <Card className="border-slate-200 shadow-sm">
        <CardHeader>
          <CardTitle>Impact Assessment</CardTitle>
          <CardDescription>
            {selectedAlert
              ? "Run full RCA + Impact evaluation"
              : "Select an alert to begin"}
          </CardDescription>
        </CardHeader>

        <CardContent>
          {!selectedAlert ? (
            <div className="text-center py-12 text-slate-500">
              <TrendingUp className="w-16 h-16 mx-auto mb-4 opacity-30" />
              <p>No Alert Selected</p>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="p-4 bg-slate-50 border rounded-lg">
                <h3 className="font-semibold text-slate-900 mb-1">
                  {selectedAlert.title}
                </h3>
                <p className="text-sm text-slate-600">
                  {selectedAlert.description}
                </p>
              </div>

              <Button
                onClick={runAnalysis}
                disabled={isAnalyzing}
                className="w-full h-12 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" /> Running...
                  </>
                ) : (
                  <>
                    <TrendingUp className="w-5 h-5 mr-2" /> Run Impact Analysis
                  </>
                )}
              </Button>

              {/* Agent Visualization */}
              {isAnalyzing && (
                <div className="p-6 bg-blue-50 border border-blue-200 rounded-lg space-y-4 text-center">
                  <div className="flex justify-center items-center gap-3 animate-pulse">
                    {agentPhase === "rca" && (
                      <>
                        <Bot className="w-6 h-6 text-blue-600 animate-spin" />
                        <p className="text-blue-900 font-medium">
                          RCA Agent analyzing disruption data...
                        </p>
                      </>
                    )}
                    {agentPhase === "impact" && (
                      <>
                        <Activity className="w-6 h-6 text-purple-700 animate-spin" />
                        <p className="text-purple-900 font-medium">
                          Impact Agent calculating cost implications...
                        </p>
                      </>
                    )}
                  </div>
                  <p className="text-sm text-blue-800 font-semibold animate-pulse">
                    {analysisStatus}
                  </p>
                </div>
              )}

              {analysisResult && !isAnalyzing && (
                <div className="space-y-5">
                  {/* RCA summary */}
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <h4 className="font-semibold text-red-900">RCA Summary</h4>
                    <p className="text-sm text-red-800 mt-1">
                      {analysisResult.rca.summary}
                    </p>
                  </div>

                  {/* Impact summary */}
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h4 className="font-semibold text-blue-900">
                      Impact Summary
                    </h4>
                    <p className="text-sm text-blue-800 mt-1">
                      {analysisResult.impact.impact_summary}
                    </p>
                  </div>

                  {/* Financial totals */}
                  <div className="grid grid-cols-3 gap-3">
                    <Card>
                      <CardContent className="p-3 text-center">
                        <p className="text-xs text-slate-500">Lost Sales</p>
                        <p className="text-lg font-semibold text-red-700">
                          ₹{analysisResult.impact.total.lost_sales.toLocaleString()}
                        </p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-3 text-center">
                        <p className="text-xs text-slate-500">SLA Penalty</p>
                        <p className="text-lg font-semibold text-orange-700">
                          ₹{analysisResult.impact.total.sla_penalty.toLocaleString()}
                        </p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="p-3 text-center">
                        <p className="text-xs text-slate-500">Overall Impact</p>
                        <p className="text-lg font-semibold text-blue-700">
                          ₹{analysisResult.impact.total.overall.toLocaleString()}
                        </p>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Assumptions */}
                  <div className="p-4 bg-slate-50 border rounded-lg">
                    <h4 className="font-semibold text-slate-900 mb-2">
                      Assumptions
                    </h4>
                    <ul className="list-disc list-inside text-sm text-slate-700">
                      {analysisResult.impact.assumptions.map((a, i) => (
                        <li key={i}>{a}</li>
                      ))}
                    </ul>
                  </div>

                  <Button
                    onClick={downloadReport}
                    variant="outline"
                    size="sm"
                    className="w-full"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download PDF
                  </Button>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ImpactAnalysis;
