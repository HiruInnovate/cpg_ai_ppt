import React, { useState, useCallback } from "react";
import { dataIntegratorApi } from "@/lib/api";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Upload,
  FileText,
  CheckCircle2,
  XCircle,
  Loader2,
  Database,
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

const DataIntegrator: React.FC = () => {
  const [isDragging, setIsDragging] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [uploadStatus, setUploadStatus] = useState<
    "idle" | "uploading" | "processing" | "success" | "error"
  >("idle");
  const [uploadResult, setUploadResult] = useState<Record<string, any> | null>(
    null
  );

  const { toast } = useToast();

  const acceptedFormats = [
    "application/json",
    "text/csv",
    "text/plain",
    ".json",
    ".csv",
    ".txt",
  ];

  const validateFile = (file: File): boolean => {
    const extension = "." + file.name.split(".").pop()?.toLowerCase();
    const isValidType = acceptedFormats.some(
      (format) => file.type === format || extension === format
    );

    if (!isValidType) {
      toast({
        title: "Invalid File Type",
        description: "Please upload a JSON, CSV, or TXT file",
        variant: "destructive",
      });
      return false;
    }

    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "File size must be less than 10MB",
        variant: "destructive",
      });
      return false;
    }

    return true;
  };

  const handleFile = async (file: File) => {
    if (!validateFile(file)) return;

    setUploadedFile(file);
    setIsUploading(true);
    setUploadProgress(0);
    setUploadStatus("uploading");
    setUploadResult(null);

    try {
      // 🔹 Actual API call with progress tracking
      const response = await dataIntegratorApi.uploadFile(file, (progress) => {
        setUploadProgress(progress);
      });

      setUploadStatus("processing");

      // Small delay for smooth UX
      await new Promise((res) => setTimeout(res, 1500));

      setUploadResult(response.result || {});
      setUploadStatus("success");

      const count =
        response.result?.stored ??
        response.result?.indexed ??
        0;
      const dtype = response.result?.type ?? "unknown";

      toast({
        title: "Upload Complete",
        description: `Processed ${count} records (${dtype})`,
      });
    } catch (error: any) {
      setUploadStatus("error");
      toast({
        title: "Upload Failed",
        description: error.message || "Error uploading file",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) handleFile(files[0]);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) handleFile(files[0]);
  };

  const resetUpload = () => {
    setUploadedFile(null);
    setUploadProgress(0);
    setUploadResult(null);
    setUploadStatus("idle");
  };

  return (
    <div className="p-6 space-y-6 bg-slate-50 min-h-full">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Data Integrator</h1>
        <p className="text-slate-600 mt-1">
          Upload supply chain data files for analysis
        </p>
      </div>

      {/* Upload Section */}
      <Card className="border-slate-200 shadow-sm">
        <CardHeader>
          <CardTitle>Upload Data File</CardTitle>
          <CardDescription>
            Drag and drop your file or click to browse
          </CardDescription>
        </CardHeader>

        <CardContent>
          <div
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            className={cn(
              "border-2 border-dashed rounded-xl p-12 text-center transition-all duration-200",
              isDragging
                ? "border-blue-500 bg-blue-50"
                : "border-slate-300 bg-slate-50 hover:border-slate-400 hover:bg-slate-100"
            )}
          >
            <input
              type="file"
              id="file-upload"
              className="hidden"
              accept=".json,.csv,.txt"
              onChange={handleFileInput}
              disabled={isUploading}
            />

            {!uploadedFile ? (
              <label htmlFor="file-upload" className="cursor-pointer">
                <div className="flex flex-col items-center gap-4">
                  <div className="p-4 bg-white rounded-full shadow-sm">
                    <Upload className="w-8 h-8 text-blue-600" />
                  </div>
                  <p className="text-lg font-semibold text-slate-900 mb-1">
                    Drop your file here or click to browse
                  </p>
                  <Button type="button" className="mt-2">
                    Select File
                  </Button>
                </div>
              </label>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-center gap-3">
                  <FileText className="w-8 h-8 text-blue-600" />
                  <div className="text-left">
                    <p className="font-semibold text-slate-900">
                      {uploadedFile.name}
                    </p>
                    <p className="text-sm text-slate-500">
                      {(uploadedFile.size / 1024).toFixed(2)} KB
                    </p>
                  </div>
                </div>

                {/* Upload Status */}
                <AnimatePresence>
                  {uploadStatus === "uploading" && (
                    <StatusBanner
                      color="blue"
                      icon={<Loader2 className="w-5 h-5 animate-spin" />}
                      text={`Uploading File... ${uploadProgress}%`}
                    />
                  )}

                  {uploadStatus === "processing" && (
                    <StatusBanner
                      color="yellow"
                      icon={<Database className="w-5 h-5 animate-bounce" />}
                      text="Processing Data... Please wait"
                    />
                  )}

                  {uploadStatus === "success" && uploadResult && (
                    <motion.div
                      initial={{ scale: 0.95, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="p-5 bg-green-100 border border-green-300 rounded-lg text-green-900 font-semibold flex flex-col gap-2 items-center"
                    >
                      <CheckCircle2 className="w-6 h-6" />
                      ✅ File processed successfully!
                      <p className="text-sm text-green-800">
                        {uploadResult.stored
                          ? `${uploadResult.stored} records stored`
                          : uploadResult.indexed
                          ? `${uploadResult.indexed} records indexed`
                          : "No records found"}
                        {" — "}
                        <span className="font-semibold">
                          {uploadResult.type ?? "unknown"}
                        </span>
                      </p>
                      {uploadResult.namespace && (
                        <p className="text-xs text-green-700">
                          Namespace: {uploadResult.namespace}
                        </p>
                      )}
                    </motion.div>
                  )}

                  {uploadStatus === "error" && (
                    <StatusBanner
                      color="red"
                      icon={<XCircle className="w-5 h-5" />}
                      text="Upload failed. Please try again."
                    />
                  )}
                </AnimatePresence>

                {uploadStatus === "uploading" && (
                  <Progress value={uploadProgress} className="h-2 mt-2" />
                )}

                {!isUploading && (
                  <Button
                    onClick={resetUpload}
                    variant="outline"
                    className="mt-4"
                  >
                    Upload Another File
                  </Button>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

const StatusBanner = ({
  color,
  icon,
  text,
}: {
  color: string;
  icon: React.ReactNode;
  text: string;
}) => (
  <motion.div
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    className={`p-4 bg-${color}-100 border border-${color}-300 rounded-lg text-${color}-900 flex items-center justify-center gap-2 font-semibold`}
  >
    {icon}
    {text}
  </motion.div>
);

export default DataIntegrator;
