// src/pages/VisionAnalyzer.tsx
import React, { useState } from "react";
import { visionApi } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Upload, Eye, AlertTriangle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const VisionAnalyzer: React.FC = () => {
  const { toast } = useToast();

  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [instructions, setInstructions] = useState(
    "Extract all visible text and key insights from this image."
  );
  const [result, setResult] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Convert uploaded image to base64 string
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => setSelectedImage(reader.result as string);
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async () => {
    if (!selectedImage) {
      toast({
        title: "No image selected",
        description: "Please upload an image to analyze.",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsAnalyzing(true);
      setResult(null);

      const base64 = selectedImage.split(",")[1]; // strip data:image/png;base64,
      const data = await visionApi.analyzeImage(base64, instructions);

      setResult(data.output);
      toast({
        title: "Analysis Complete",
        description: `Model used: ${data.model}`,
      });
    } catch (error) {
      toast({
        title: "Analysis Failed",
        description: "An error occurred while analyzing the image.",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="p-6 bg-slate-50 min-h-screen">
      <h1 className="text-3xl font-bold text-slate-900 mb-2 flex items-center gap-2">
        <Eye className="w-7 h-7 text-blue-600" /> Vision Analyzer
      </h1>
      <p className="text-slate-600 mb-6">
        Upload an image and get extracted details using OpenAI’s Vision API.
      </p>

      <Card className="shadow-sm border-slate-200">
        <CardHeader>
          <CardTitle>🖼️ Upload Image</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <input
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            className="block w-full text-sm text-slate-700 border border-slate-300 rounded-lg cursor-pointer bg-white file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
          />

          {selectedImage && (
            <div className="mt-4 flex justify-center">
              <img
                src={selectedImage}
                alt="Uploaded Preview"
                className="max-h-64 rounded-lg border border-slate-200 shadow-sm"
              />
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="shadow-sm border-slate-200 mt-6">
        <CardHeader>
          <CardTitle>🧠 Analysis Instructions</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            value={instructions}
            onChange={(e) => setInstructions(e.target.value)}
            className="w-full h-24 text-sm border-slate-300"
          />
        </CardContent>
      </Card>

      <div className="flex justify-end mt-6">
        <Button
          onClick={handleAnalyze}
          disabled={isAnalyzing}
          className="bg-blue-600 hover:bg-blue-700 text-white"
        >
          {isAnalyzing ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Analyzing...
            </>
          ) : (
            <>
              <Upload className="w-4 h-4 mr-2" /> Analyze Image
            </>
          )}
        </Button>
      </div>

      {result && (
        <Card className="mt-8 border-green-200 bg-green-50 shadow-sm">
          <CardHeader>
            <CardTitle>📋 Extracted Details</CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="text-sm whitespace-pre-wrap bg-white p-4 rounded-md border border-slate-200 text-slate-800">
              {result}
            </pre>
          </CardContent>
        </Card>
      )}

      {!result && !isAnalyzing && (
        <div className="text-center mt-12 text-slate-500">
          <AlertTriangle className="w-6 h-6 mx-auto mb-2 opacity-60" />
          <p>Upload an image and click “Analyze” to get started.</p>
        </div>
      )}
    </div>
  );
};

export default VisionAnalyzer;
