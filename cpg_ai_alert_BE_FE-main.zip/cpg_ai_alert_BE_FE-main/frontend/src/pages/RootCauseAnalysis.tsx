import React, { useState, useEffect } from "react";
import { Alert, RCAResult } from "@/types";
import { alertsApi, rcaApi } from "@/lib/api";
import { v4 as uuidv4 } from "uuid";
import { useAgentStream } from "@/hooks/useAgentStream";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Search,
  Loader2,
  Download,
  CheckCircle,
  AlertCircle,
  ChevronDown,
  ChevronUp,
  Bot,
  Workflow,
  Activity,
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import jsPDF from "jspdf";
import { motion, AnimatePresence } from "framer-motion";
import AgentStreamVisualizer from "@/components/ui/AgentStreamVisualizer";

const RootCauseAnalysis: React.FC = () => {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null);
  const [isLoadingAlerts, setIsLoadingAlerts] = useState(true);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<RCAResult | null>(null);
  const [analysisStatus, setAnalysisStatus] = useState("");
  const [isAlertSectionOpen, setIsAlertSectionOpen] = useState(true);
  const [agentPhase, setAgentPhase] = useState<"idle" | "rca" | "pattern" | "insight">("idle");
  const { toast } = useToast();

  const [sessionId, setSessionId] = useState<string | null>(null);
  const events = useAgentStream(sessionId || undefined);

  useEffect(() => {
    loadAlerts();
  }, []);

  const loadAlerts = async () => {
    setIsLoadingAlerts(true);
    try {
      const data = await alertsApi.getAlerts();
      setAlerts(data.filter((a) => a.status !== "resolved"));
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load alerts",
        variant: "destructive",
      });
    } finally {
      setIsLoadingAlerts(false);
    }
  };

  // const runAnalysis = async () => {
  //   if (!selectedAlert) return;
  //   setIsAnalyzing(true);
  //   setAnalysisResult(null);
  //   setAgentPhase("rca");
  //   setAnalysisStatus("Initializing RCA agent...");

  //   try {
  //     setTimeout(() => {
  //       setAnalysisStatus("🧠 RCA Agent analyzing shipment disruptions...");
  //       setAgentPhase("rca");
  //     }, 500);

  //     setTimeout(() => {
  //       setAnalysisStatus("🔍 Pattern engine detecting correlations...");
  //       setAgentPhase("pattern");
  //     }, 2500);

  //     setTimeout(() => {
  //       setAnalysisStatus("💡 Generating final insights...");
  //       setAgentPhase("insight");
  //     }, 4500);

  //     const result = await rcaApi.runAnalysis(selectedAlert);
  //     setAnalysisResult(result);

  //     toast({
  //       title: "Analysis Complete",
  //       description: "Root cause analysis generated successfully",
  //     });
  //   } catch (error) {
  //     toast({
  //       title: "Analysis Failed",
  //       description: "An error occurred during analysis",
  //       variant: "destructive",
  //     });
  //   } finally {
  //     setIsAnalyzing(false);
  //     setAnalysisStatus("");
  //     setAgentPhase("idle");
  //   }
  // };

  const runAnalysis = async () => {
  if (!selectedAlert) return;
  const sid = uuidv4();
  setSessionId(sid);

  setIsAnalyzing(true);
  setAnalysisResult(null);
  setAgentPhase("rca");
  setAnalysisStatus("Initializing RCA agent...");

  try {
    // Trigger backend analysis with WebSocket session ID
    const resultPromise = rcaApi.runAnalysis(selectedAlert, sid);

    // UI progression animation (same as before)
    setTimeout(() => setAnalysisStatus("🧠 RCA Agent analyzing shipment disruptions..."), 500);
    setTimeout(() => setAnalysisStatus("🔍 Pattern engine detecting correlations..."), 2500);
    setTimeout(() => setAnalysisStatus("💡 Generating final insights..."), 4500);

    // Wait for agent to complete
    const result = await resultPromise;
    setAnalysisResult(result);

    toast({
      title: "Analysis Complete",
      description: "Root cause analysis generated successfully",
    });
  } catch (error) {
    toast({
      title: "Analysis Failed",
      description: "An error occurred during analysis",
      variant: "destructive",
    });
  } finally {
    setIsAnalyzing(false);
    setAnalysisStatus("");
    setAgentPhase("idle");
  }
};

  const downloadReport = () => {
    if (!analysisResult || !selectedAlert) return;

    const doc = new jsPDF();
    const marginLeft = 10;
    let y = 10;

    doc.setFontSize(14);
    doc.text("Root Cause Analysis Report", marginLeft, y);
    y += 10;

    doc.setFontSize(11);
    doc.text(`Alert: ${selectedAlert.title}`, marginLeft, y);
    y += 8;
    doc.text(`Date: ${new Date().toLocaleString()}`, marginLeft, y);
    y += 10;

    doc.text("-----------------------------------------", marginLeft, y);
    y += 10;

    doc.setFontSize(12);
    doc.text("Summary:", marginLeft, y);
    y += 8;
    doc.setFontSize(10);
    const summaryLines = doc.splitTextToSize(analysisResult.summary, 180);
    doc.text(summaryLines, marginLeft, y);
    y += summaryLines.length * 6 + 8;

    doc.setFontSize(12);
    doc.text("Root Causes Identified:", marginLeft, y);
    y += 8;
    doc.setFontSize(10);
    analysisResult.causes.forEach((cause, i) => {
      const causeText = `${i + 1}. ${cause.label}: ${cause.explanation}`;
      const causeLines = doc.splitTextToSize(causeText, 180);
      doc.text(causeLines, marginLeft, y);
      y += causeLines.length * 6 + 4;
    });
    y += 6;

    doc.setFontSize(12);
    doc.text("Recommendations:", marginLeft, y);
    y += 8;
    doc.setFontSize(10);
    analysisResult.recommendations.forEach((r, i) => {
      const recText = `${i + 1}. ${r.action} (ETA: ${r.eta_hours}h, Conf: ${(r.confidence_est * 100).toFixed(0)}%)`;
      const recLines = doc.splitTextToSize(recText, 180);
      doc.text(recLines, marginLeft, y);
      y += recLines.length * 6 + 4;
    });

    doc.save(`RCA_${selectedAlert.id}.pdf`);

    toast({
      title: "Report Downloaded",
      description: "Analysis report has been saved as PDF",
    });
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-red-100 text-red-800 border-red-200";
      case "high":
        return "bg-orange-100 text-orange-800 border-orange-200";
      case "medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "low":
        return "bg-blue-100 text-blue-800 border-blue-200";
      default:
        return "bg-slate-100 text-slate-800 border-slate-200";
    }
  };

  return (
    <div className="p-6 bg-slate-50 min-h-full">
      <h1 className="text-3xl font-bold text-slate-900 mb-1">
        Root Cause Analysis
      </h1>
      <p className="text-slate-600 mb-4">
        Analyze disruptions to identify root causes
      </p>

      {/* Collapsible Alert Section */}
      <Card className="border-slate-200 shadow-sm mb-6">
        <CardHeader
          className="flex flex-row justify-between items-center cursor-pointer"
          onClick={() => setIsAlertSectionOpen(!isAlertSectionOpen)}
        >
          <div>
            <CardTitle>Select Alert</CardTitle>
            <CardDescription>Choose an alert to analyze</CardDescription>
          </div>
          {isAlertSectionOpen ? (
            <ChevronUp className="w-5 h-5 text-slate-600" />
          ) : (
            <ChevronDown className="w-5 h-5 text-slate-600" />
          )}
        </CardHeader>

        {isAlertSectionOpen && (
          <CardContent>
            <div className="space-y-3 max-h-[400px] overflow-y-auto">
              {isLoadingAlerts ? (
                Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-24 w-full" />
                ))
              ) : alerts.length === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  <AlertCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No active alerts available</p>
                </div>
              ) : (
                alerts.map((alert) => (
                  <Card
                    key={alert.id}
                    className={`cursor-pointer transition-all border-2 ${
                      selectedAlert?.id === alert.id
                        ? "border-blue-500 bg-blue-50"
                        : "border-slate-200 hover:border-slate-300 hover:shadow-md"
                    }`}
                    onClick={() => setSelectedAlert(alert)}
                  >
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-semibold text-slate-900">
                            {alert.title}
                          </h3>
                          <p className="text-sm text-slate-600 mt-1">
                            {alert.description}
                          </p>
                          <div className="flex flex-wrap gap-2 mt-2">
                            <Badge
                              className={getSeverityColor(alert.severity)}
                              variant="outline"
                            >
                              {alert.severity}
                            </Badge>
                            <Badge variant="outline">{alert.type}</Badge>
                          </div>
                        </div>
                        {selectedAlert?.id === alert.id && (
                          <CheckCircle className="w-5 h-5 text-blue-600" />
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </CardContent>
        )}
      </Card>

      {/* Analysis Section */}
      <Card className="border-slate-200 shadow-sm">
        <CardHeader>
          <CardTitle>Root Cause Evaluation</CardTitle>
          <CardDescription>
            {selectedAlert
              ? "Run automated root cause reasoning"
              : "Select an alert to begin analysis"}
          </CardDescription>
        </CardHeader>

        <CardContent>
          {!selectedAlert ? (
            <div className="text-center py-12 text-slate-500">
              <Search className="w-16 h-16 mx-auto mb-4 opacity-30" />
              <p>No Alert Selected</p>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="p-4 bg-slate-50 border rounded-lg">
                <h3 className="font-semibold text-slate-900 mb-1">
                  {selectedAlert.title}
                </h3>
                <p className="text-sm text-slate-600">
                  {selectedAlert.description}
                </p>
              </div>

              <Button
                onClick={runAnalysis}
                disabled={isAnalyzing}
                className="w-full h-12 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Search className="w-5 h-5 mr-2" />
                    Analyze Root Cause
                  </>
                )}
              </Button>

              {/* Agent Simulation Visualization */}
              {isAnalyzing && (
                <div className="p-6 bg-blue-50 border border-blue-200 rounded-lg space-y-4 text-center">
                  <div className="flex justify-center items-center gap-3 animate-pulse">
                    {agentPhase === "rca" && (
                      <>
                        <Bot className="w-6 h-6 text-blue-600 animate-spin" />
                        <p className="text-blue-900 font-medium">
                          RCA Agent analyzing disruption data...
                        </p>
                      </>
                    )}
                    {agentPhase === "pattern" && (
                      <>
                        <Activity className="w-6 h-6 text-purple-700 animate-spin" />
                        <p className="text-purple-900 font-medium">
                          Pattern Engine finding correlations...
                        </p>
                      </>
                    )}
                    {agentPhase === "insight" && (
                      <>
                        <Workflow className="w-6 h-6 text-green-700 animate-spin" />
                        <p className="text-green-900 font-medium">
                          Synthesizing insights for recommendations...
                        </p>
                      </>
                    )}
                  </div>
                  <p className="text-sm text-blue-800 font-semibold animate-pulse">
                    {analysisStatus}
                  </p>
                </div>
              )}

              {/* Live WebSocket Reasoning Stream
              {isAnalyzing && sessionId && (
                <div className="mt-4 p-4 bg-slate-100 border border-slate-200 rounded-md">
                  <h4 className="text-slate-800 font-semibold mb-2 flex items-center gap-2">
                    <Bot className="w-4 h-4 text-blue-600" />
                    Live Agent Stream
                  </h4>
                  <div className="max-h-64 overflow-y-auto text-left text-sm font-mono bg-white p-3 border border-slate-200 rounded-md">
                    {events.length === 0 ? (
                      <p className="text-slate-500">Waiting for reasoning updates...</p>
                    ) : (
                      events.map((e, idx) => (
                        <div key={idx} className="mb-1">
                          <span className="text-blue-700 font-medium">{e.event.toUpperCase()}</span>
                          <span className="ml-2 text-slate-800">{e.message}</span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )} */}

              {/* Live WebSocket Reasoning Stream */}
              {isAnalyzing && sessionId && (
                <AgentStreamVisualizer events={events} />
              )}



              {/* Analysis Results */}
              {analysisResult && !isAnalyzing && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-slate-900">
                      Analysis Results
                    </h3>
                    <Button
                      onClick={downloadReport}
                      variant="outline"
                      size="sm"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download PDF
                    </Button>
                  </div>

                  {/* Summary */}
                  <Card className="border-red-200 bg-red-50">
                    <CardContent className="p-4">
                      <h4 className="font-semibold text-red-900 mb-2">
                        Root Cause Summary
                      </h4>
                      <p className="text-sm text-red-800">
                        {analysisResult.summary}
                      </p>
                      <p className="text-xs text-slate-600 mt-2">
                        Confidence: {(analysisResult.confidence * 100).toFixed(1)}%
                      </p>
                    </CardContent>
                  </Card>

                  {/* Causes */}
                  <Card className="border-yellow-200 bg-yellow-50">
                    <CardContent className="p-4">
                      <h4 className="font-semibold text-yellow-900 mb-3">
                        Causes Identified
                      </h4>
                      {analysisResult.causes.map((c, i) => (
                        <p key={i} className="text-sm text-slate-800">
                          <strong>{c.label}:</strong> {c.explanation}
                        </p>
                      ))}
                    </CardContent>
                  </Card>

                  {/* Recommendations */}
                  <Card className="border-green-200 bg-green-50">
                    <CardContent className="p-4">
                      <h4 className="font-semibold text-green-900 mb-3">
                        Recommendations
                      </h4>
                      <ul className="space-y-2">
                        {analysisResult.recommendations.map((r, i) => (
                          <li key={i} className="text-sm text-green-800">
                            <span className="font-medium">{i + 1}.</span> {r.action}{" "}
                            <span className="text-xs text-slate-500">
                              (ETA: {r.eta_hours}h, Conf: {(r.confidence_est * 100).toFixed(0)}%)
                            </span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>

                  {/* Agent Reasoning Steps */}
                  <div>
                    <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                      <Workflow className="w-5 h-5 text-blue-600" />
                      Agent Reasoning Steps
                    </h4>
                    <div className="relative border-l-2 border-blue-200 ml-3 pl-4 space-y-4">
                      {analysisResult.steps.map((step, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.2 }}
                          className="bg-white border border-slate-200 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow"
                        >
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-xs text-blue-600 font-semibold">
                              Step {step.step}
                            </span>
                            <Badge
                              variant="outline"
                              className="bg-blue-50 text-blue-700 border-blue-200"
                            >
                              {step.tool}
                            </Badge>
                          </div>
                          <p className="text-xs text-slate-600 mb-2">
                            <strong>Input:</strong> {step.tool_input}
                          </p>
                          <pre className="text-xs bg-slate-50 border border-slate-100 rounded p-2 whitespace-pre-wrap">
                            {step.observation}
                          </pre>
                        </motion.div>
                      ))}
                    </div>
                  </div>

                  {/* Logs */}
                  <details className="p-4 bg-slate-50 border border-slate-200 rounded-lg">
                    <summary className="cursor-pointer text-blue-700 font-medium">
                      🧠 View Agent Logs
                    </summary>
                    <pre className="mt-3 text-xs whitespace-pre-wrap text-slate-700 bg-white p-3 rounded-md border border-slate-100 overflow-x-auto">
                      {analysisResult.logs}
                    </pre>
                  </details>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default RootCauseAnalysis;
