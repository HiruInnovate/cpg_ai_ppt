// src/components/AgentStreamVisualizer.tsx
import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Bot, Brain, Hammer, Eye, CheckCircle2, AlertTriangle, Loader2 } from "lucide-react";
import { AgentEvent } from "@/hooks/useAgentStream";

interface Props {
  events: AgentEvent[];
}

const eventStyles: Record<string, { color: string; icon: JSX.Element }> = {
  start: { color: "text-blue-700", icon: <Bot className="w-4 h-4 text-blue-700" /> },
  thought: { color: "text-purple-700", icon: <Brain className="w-4 h-4 text-purple-700" /> },
  action: { color: "text-amber-700", icon: <Hammer className="w-4 h-4 text-amber-700" /> },
  observation: { color: "text-green-700", icon: <Eye className="w-4 h-4 text-green-700" /> },
  result: { color: "text-emerald-700", icon: <CheckCircle2 className="w-4 h-4 text-emerald-700" /> },
  finish: { color: "text-blue-800", icon: <CheckCircle2 className="w-4 h-4 text-blue-800" /> },
  error: { color: "text-red-700", icon: <AlertTriangle className="w-4 h-4 text-red-700" /> },
};

const AgentStreamVisualizer: React.FC<Props> = ({ events }) => {
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4 max-h-[450px] overflow-y-auto shadow-sm">
      <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
        <Bot className="w-5 h-5 text-blue-600" />
        Agent Reasoning Stream
      </h4>

      <AnimatePresence>
        {events.length === 0 && (
          <div className="flex items-center justify-center py-12 text-slate-400 text-sm">
            <Loader2 className="animate-spin w-4 h-4 mr-2" /> Waiting for updates...
          </div>
        )}

        {events.map((ev) => {
          const style = eventStyles[ev.event] || eventStyles["thought"];
          return (
            <motion.div
              key={ev.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className={`p-3 mb-2 rounded-lg border border-slate-100 bg-slate-50 flex items-start gap-3 shadow-xs`}
            >
              <div className="mt-0.5">{style.icon}</div>
              <div className="flex-1">
                <p className={`font-medium ${style.color}`}>
                  {ev.event.toUpperCase()}
                </p>
                <p className="text-sm text-slate-700 whitespace-pre-wrap break-words">
                  {ev.message}
                </p>
              </div>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
};

export default AgentStreamVisualizer;
