import React, { useEffect, useState } from "react";

const AgentStream = ({ sessionId }: { sessionId: string }) => {
  const [logs, setLogs] = useState<{ event: string; message: string }[]>([]);

  useEffect(() => {
    const ws = new WebSocket(`ws://localhost:8000/ws/agent/${sessionId}`);

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      setLogs((prev) => [...prev, data]);
    };

    ws.onclose = () => console.log("WebSocket closed");
    ws.onerror = (e) => console.error("WebSocket error", e);

    return () => ws.close();
  }, [sessionId]);

  return (
    <div className="bg-white p-4 border rounded-md max-h-[500px] overflow-auto">
      <h2 className="font-semibold mb-2">🧠 Agent Reasoning Stream</h2>
      {logs.map((l, i) => (
        <div key={i} className="text-sm mb-1">
          <strong>{l.event}:</strong> {l.message}
        </div>
      ))}
    </div>
  );
};

export default AgentStream;
