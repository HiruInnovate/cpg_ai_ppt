// src/hooks/useAgentStream.ts
import { useEffect, useState } from "react";

export interface AgentEvent {
  id: string;
  event: "start" | "thought" | "action" | "observation" | "result" | "finish" | "error";
  message: string;
  meta?: any;
  timestamp: number;
}

export function useAgentStream(sessionId?: string) {
  const [events, setEvents] = useState<AgentEvent[]>([]);

  useEffect(() => {
    if (!sessionId) return;

    const ws = new WebSocket(`ws://localhost:8000/ws/agent/${sessionId}`);
    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        setEvents((prev) => [
          ...prev,
          {
            id: crypto.randomUUID(),
            event: data.event?.toLowerCase() || "unknown",
            message: data.message,
            meta: data.meta,
            timestamp: Date.now(),
          },
        ]);
      } catch (err) {
        console.warn("Invalid WS data", err);
      }
    };

    ws.onerror = (err) => console.error("WebSocket error:", err);
    ws.onclose = () => {
        console.log("WebSocket closed for session:", sessionId);
        setEvents([]);
    }

    return () => ws.close();
  }, [sessionId]);

  return events;
}
