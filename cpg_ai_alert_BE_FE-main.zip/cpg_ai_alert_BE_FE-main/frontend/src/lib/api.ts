import axios from 'axios';
import { Alert, RCAResponse, RCAResult, ImpactResult, ChatMessage } from '@/types';
import { v4 as uuidv4 } from "uuid";

const api = axios.create({
  baseURL: '/api', // This would be your actual API base URL
  timeout: 30000,
});

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";

const mockAlerts: Alert[] = [
  {
    id: '1',
    title: 'Semiconductor Shortage',
    description: 'Critical shortage of semiconductor chips affecting production lines',
    severity: 'critical',
    type: 'Supply Shortage',
    date: '2024-01-15',
    status: 'active',
    location: 'Taiwan',
    affectedProducts: ['Electronics', 'Automotive']
  },
  {
    id: '2',
    title: 'Port Congestion',
    description: 'Major delays at Los Angeles port due to labor disputes',
    severity: 'high',
    type: 'Logistics',
    date: '2024-01-14',
    status: 'investigating',
    location: 'Los Angeles, USA',
    affectedProducts: ['Consumer Goods', 'Electronics']
  },
  {
    id: '3',
    title: 'Raw Material Price Surge',
    description: 'Steel prices increased by 40% due to supply constraints',
    severity: 'medium',
    type: 'Price Volatility',
    date: '2024-01-13',
    status: 'active',
    location: 'Global',
    affectedProducts: ['Manufacturing', 'Construction']
  },
  {
    id: '4',
    title: 'Weather Disruption',
    description: 'Severe storms affecting shipping routes in Pacific',
    severity: 'high',
    type: 'Natural Disaster',
    date: '2024-01-12',
    status: 'resolved',
    location: 'Pacific Ocean',
    affectedProducts: ['All Categories']
  },
  {
    id: '5',
    title: 'Supplier Bankruptcy',
    description: 'Key supplier filed for bankruptcy affecting multiple supply chains',
    severity: 'critical',
    type: 'Supplier Issue',
    date: '2024-01-11',
    status: 'investigating',
    location: 'Germany',
    affectedProducts: ['Automotive', 'Industrial']
  }
];

export const alertsApi = {
  getAlerts: async (): Promise<Alert[]> => {
    try {
      const response = await fetch(`${API_BASE_URL}/alerts/`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      // Transform backend alert objects to match UI Alert type
      const alerts: Alert[] = (data.alerts || []).map((a: any) => ({
        id: a.alert_id,
        title: `Shipment ${a.shipment_id}`,
        description: a.summary,
        severity: a.severity.toLowerCase(), // High → high
        status: a.status.toLowerCase(), // Active → active
        type: "Delay", // backend doesn’t have "type" yet
        date: a.created_at,
        location: a.summary.match(/at\s([\w_]+)/)?.[1]?.replace("_", " "), // Extracts 'WH_Bangalore' → 'WH Bangalore'
      }));

      return alerts;
    } catch (error) {
      console.error("Error fetching alerts:", error);
      return [];
    }
  },
};

export const dataIntegratorApi = {
  uploadFile: async (
    file: File,
    onProgress?: (progress: number) => void
  ): Promise<{
    success: boolean;
    message: string;
    filename?: string;
    result?: Record<string, any>;
  }> => {
    const API_BASE_URL =
      import.meta.env.VITE_API_BASE_URL || "http://localhost:8000";

    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      const formData = new FormData();
      formData.append("file", file);

      xhr.open("POST", `${API_BASE_URL}/data/upload`, true);

      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable && onProgress) {
          const percent = Math.round((event.loaded / event.total) * 100);
          onProgress(percent);
        }
      };

      xhr.onload = () => {
        try {
          const response = JSON.parse(xhr.responseText);
          if (xhr.status >= 200 && xhr.status < 300) {
            resolve({
              success: true,
              message: response.message || "File uploaded successfully.",
              filename: response.filename,
              result: response.result,
            });
          } else {
            reject(new Error(response.detail || "Upload failed"));
          }
        } catch {
          reject(new Error("Invalid server response"));
        }
      };

      xhr.onerror = () => reject(new Error("Network error during upload"));
      xhr.send(formData);
    });
  },
};
export const rcaApi = {
  runAnalysis: async (alert: Alert, sessionId?: string): Promise<RCAResult> => {
    try {
      const sid = sessionId || uuidv4();

      const response = await fetch(`${API_BASE_URL}/rca/run?session_id=${sid}`, {

        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          alert_id: alert.id,
          summary: alert.description,
          severity: alert.severity,
          location: alert.location,
          status: alert.status,
        }),
      });

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data: RCAResponse = await response.json();
      if (data.status !== 'success' || !data.rca) throw new Error('Invalid RCA response');

      const final = data.rca.final_json;

      return {
        alertId: alert.id,
        summary: final.summary,
        causes: final.causes,
        recommendations: final.recommendations,
        evidence: final.evidence,
        confidence: final.confidence,
        logs: data.rca.logs,
        steps: data.rca.steps,
      };
    } catch (error) {
      console.error('RCA API error:', error);
      throw error;
    }
  },
};

export const impactApi = {
  runAnalysis: async (alert: Alert): Promise<ImpactResult> => {
    const response = await fetch(`http://localhost:8000/impact/run`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ alert }),
    });

    if (!response.ok) throw new Error("Impact analysis failed");

    const json = await response.json();
    if (json.status !== "success" || !json.data) {
      throw new Error("Invalid backend response");
    }

    return {
      alert_id: json.alert_id,
      rca: json.data.rca,
      impact: json.data.impact,
      traces: json.data.traces,
      logs: json.data.logs,
    };
  },
};

export const chatApi = {
  sendMessage: async (messages: ChatMessage[]): Promise<ChatMessage> => {
    const lastMessage = messages[messages.length - 1];

    try {
      const response = await fetch(`${API_BASE_URL}/chat/query`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          user_id: 'demo_user_001', // can be dynamic if you support multiple users
          message: lastMessage.content,
        }),
      });

      if (!response.ok) {
        throw new Error(`Backend returned ${response.status}`);
      }

      const data = await response.json();

      // Expecting backend response like:
      // { "status": "success", "message": "...", "action": "rca_analysis" }

      return {
        id: Date.now().toString(),
        role: 'assistant',
        content: data.message || 'No response from backend.',
        timestamp: new Date().toISOString(),
        meta: {
          action: data.action || 'unknown',
          status: data.status || 'unknown',
        },
      };
    } catch (error: any) {
      console.error('[chatApi] Error sending message:', error);
      return {
        id: Date.now().toString(),
        role: 'assistant',
        content:
          '⚠️ Sorry, something went wrong connecting to the backend. Please try again.',
        timestamp: new Date().toISOString(),
      };
    }
  },
};


export interface VisionResponse {
  status: string;
  output: string;
  model: string;
}

export const visionApi = {
  analyzeImage: async (imageBase64: string, instructions: string): Promise<VisionResponse> => {
    try {
      const response = await fetch(`${API_BASE_URL}/vision/analyze`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          image_base64: imageBase64,
          instructions,
        }),
      });

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const data = await response.json();
      if (data.status !== "success") throw new Error(data.message || "Vision analysis failed");

      return data;
    } catch (error) {
      console.error("[Vision API Error]:", error);
      throw error;
    }
  },
};