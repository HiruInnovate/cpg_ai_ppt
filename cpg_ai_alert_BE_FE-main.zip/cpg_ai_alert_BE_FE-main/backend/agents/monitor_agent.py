# backend/services/storage.py
import json
import os
import threading
from pathlib import Path
from backend.services.logger_config import get_logger

logger = get_logger(__name__)
_lock = threading.Lock()

# ---------- Path resolution (robust & configurable) ----------
# backend/ directory (…/cpg_ai_alert_BE_FE/backend)
BACKEND_ROOT: Path = Path(__file__).resolve().parents[1]

# Allow override via env, else default to backend/data/json_store
DATA_DIR: Path = Path(
    os.getenv("BACKEND_DATA_DIR", str(BACKEND_ROOT / "data" / "json_store"))
).resolve()

DATA_DIR.mkdir(parents=True, exist_ok=True)
logger.info(f"[STORAGE] Using data dir: {DATA_DIR}")

def _path(fn: str) -> Path:
    """Resolve full path for a JSON file inside the data store."""
    return (DATA_DIR / fn).resolve()

# ---------- IO helpers ----------
def load_json(fn: str):
    """
    Safely load JSON from the data store.
    Returns [] if file not found or invalid JSON.
    """
    p = _path(fn)
    try:
        if not p.exists():
            logger.warning(f"[STORAGE] File not found: {p}. Returning empty list.")
            return []
        with p.open("r", encoding="utf8") as f:
            data = json.load(f)
            logger.debug(
                f"[STORAGE] Loaded "
                f"{(len(data) if isinstance(data, list) else 'object')} from {p.name}."
            )
            return data
    except json.JSONDecodeError as e:
        logger.error(f"[STORAGE] JSON decode error in {p.name}: {e}", exc_info=True)
        return []
    except Exception as e:
        logger.error(f"[STORAGE] Error loading {p.name}: {e}", exc_info=True)
        return []

def save_json(fn: str, data):
    """
    Overwrite a JSON file atomically with a lock.
    Creates directories if needed.
    """
    p = _path(fn)
    try:
        with _lock:
            p.parent.mkdir(parents=True, exist_ok=True)
            with p.open("w", encoding="utf8") as f:
                json.dump(data, f, indent=2, default=str)
            logger.info(
                f"[STORAGE] Saved {(len(data) if isinstance(data, list) else 'object')} to {p.name}."
            )
    except Exception as e:
        logger.error(f"[STORAGE] Failed to save {p.name}: {e}", exc_info=True)

def append_json(fn: str, obj):
    """
    Append a single object to a JSON list file (creates file if missing).
    If existing file is not a list, it will be replaced with a list.
    """
    try:
        items = load_json(fn)
        if not isinstance(items, list):
            logger.warning(f"[STORAGE] {fn} is not a list. Overwriting with a new list.")
            items = []
        items.append(obj)
        save_json(fn, items)
        logger.info(f"[STORAGE] Appended record to {fn} (total={len(items)}).")
    except Exception as e:
        logger.error(f"[STORAGE] Error appending to {fn}: {e}", exc_info=True)

def overwrite_json(fn: str, obj):
    """Replace file content completely with provided object/list."""
    try:
        save_json(fn, obj)
    except Exception as e:
        logger.error(f"[STORAGE] Error overwriting {fn}: {e}", exc_info=True)
