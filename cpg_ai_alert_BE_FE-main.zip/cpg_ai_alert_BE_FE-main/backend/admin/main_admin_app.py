import io

import streamlit as st
from pathlib import Path

st.set_page_config(
    page_title="CPG AI Admin Portal",
    layout="wide",
    page_icon="🧠"
)

st.sidebar.image("https://cdn-icons-png.flaticon.com/512/1046/1046869.png", width=50)
st.sidebar.title("CPG AI Admin Portal")

st.sidebar.markdown("---")

pages = {
    "📊 Agent Logs & Dashboard": "1_Admin_Dashboard",
    "🧩 Agent Trace Inspector": "2_Agent_TraceViewer",
    "🧠 LLM Evaluation (RAGAS)": "3_Agent_Evaluation",
    "🛡️ Guardrails Management": "4_Admin_Guardrails",
    "📈 Metrics & Summaries": "5_Admin_Metrics",
}

choice = st.sidebar.radio("Navigate", list(pages.keys()))

selected = pages[choice]
st.sidebar.markdown("---")
st.sidebar.info("Monitor and evaluate AI Agents in real-time.")

try:
    with io.open(f"{selected}.py", "r", encoding="utf-8") as f:
        code = f.read()
    exec(code)
except UnicodeDecodeError as e:
    st.error(f"Encoding error while loading {selected}.py — please save it in UTF-8 format.\n\n{e}")
