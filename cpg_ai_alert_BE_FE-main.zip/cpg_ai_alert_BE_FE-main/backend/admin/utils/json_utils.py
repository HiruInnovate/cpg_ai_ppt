import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1] / "json_store"


def load_json(filename: str):
    path = BASE_DIR / filename
    if not path.exists():
        return []
    with open(path, "r") as f:
        return json.load(f)


def save_json(filename: str, data):
    path = BASE_DIR / filename
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
