import os
import json
from pathlib import Path
import pandas as pd
import streamlit as st
import plotly.express as px
from datetime import datetime

# --- Page Config ---
st.set_page_config(page_title="Agent Trace Inspector", layout="wide", page_icon="🧩")
st.title("🧩 Agent Trace Inspector")
st.caption("Inspect detailed execution traces, errors, and outputs of individual agents")

# --- Load Data ---
runs_path  = "../data/json_store/agent_runs.json"

if not os.path.exists(runs_path):
    st.error("❌ No agent_runs.json found in json_store directory.")
    st.stop()

with open(runs_path, "r", encoding="utf-8") as f:
    data = json.load(f)

if not data:
    st.warning("⚠️ No agent run data available.")
    st.stop()

df = pd.DataFrame(data)
df["timestamp"] = pd.to_datetime(df["timestamp"])
df = df.sort_values("timestamp", ascending=False)

# --- Sidebar Filters ---
st.sidebar.header("🔍 Filters")
agents = sorted(df["agent"].unique())
selected_agents = st.sidebar.multiselect("Select Agent(s)", agents, default=agents)
alerts = sorted(df["alert_id"].unique())
selected_alerts = st.sidebar.multiselect("Select Alert(s)", alerts, default=alerts)

filtered_df = df[df["agent"].isin(selected_agents) & df["alert_id"].isin(selected_alerts)]

# --- Summary Cards ---
st.markdown("### 📊 Summary Insights")
col1, col2, col3 = st.columns(3)
col1.metric("Total Filtered Runs", len(filtered_df))
col2.metric("Unique Alerts", len(filtered_df["alert_id"].unique()))
col3.metric("Unique Agents", len(filtered_df["agent"].unique()))

# --- Timeline Visualization ---
st.markdown("### 🕒 Agent Run Timeline")
fig = px.scatter(
    filtered_df,
    x="timestamp",
    y="agent",
    color=filtered_df["agent"].apply(lambda x: "Error" if "Error" in x else "Normal"),
    hover_data=["run_id", "alert_id", "input", "raw_output"],
    title="Agent Execution Timeline",
    color_discrete_map={"Error": "red", "Normal": "blue"},
    size_max=12,
)
fig.update_layout(
    xaxis_title="Timestamp",
    yaxis_title="Agent Name",
    height=400,
    margin=dict(l=20, r=20, t=60, b=40),
)
st.plotly_chart(fig, use_container_width=True)

# --- Alert-wise Trace Grouping ---
st.markdown("### 🧩 Agent Traces by Alert")
for alert_id, group in filtered_df.groupby("alert_id"):
    with st.expander(f"🚨 Alert: {alert_id} — {len(group)} agent runs", expanded=False):
        st.markdown(f"**Agents involved:** {', '.join(sorted(group['agent'].unique()))}")
        st.markdown("#### 📜 Execution Sequence")
        timeline = group.sort_values("timestamp")[["agent", "timestamp", "run_id"]]
        st.dataframe(timeline, use_container_width=True, hide_index=True)

# --- Agent-level Detailed Inspection ---
st.markdown("### 🔬 Inspect Agent Run Details")

selected_agent = st.selectbox("Select Agent", sorted(filtered_df["agent"].unique()))
agent_runs = filtered_df[filtered_df["agent"] == selected_agent].sort_values("timestamp", ascending=False)

if not agent_runs.empty:
    selected_run = st.selectbox("Select Run ID", agent_runs["run_id"].tolist())
    details = agent_runs[agent_runs["run_id"] == selected_run].iloc[0].to_dict()

    st.markdown(f"#### 🧠 Agent: `{details['agent']}` | Alert: `{details['alert_id']}`")
    st.markdown(f"**Timestamp:** `{details['timestamp']}`")
    st.markdown("---")

    colA, colB = st.columns([2, 1])
    with colA:
        st.markdown("#### 🧩 Input Command")
        st.code(details["input"], language="bash")

        st.markdown("#### 🧾 Raw Output")
        st.code(details["raw_output"], language="json")

        if isinstance(details.get("parsed_output"), dict) and details["parsed_output"]:
            st.markdown("#### 🪄 Parsed Output")
            st.json(details["parsed_output"])
    with colB:
        st.markdown("#### ⚙️ Run Metadata")
        st.write({
            "Run ID": details["run_id"],
            "Agent": details["agent"],
            "Alert ID": details["alert_id"],
            "Timestamp": str(details["timestamp"]),
        })

    # Highlight Errors Clearly
    if "Error" in details["agent"] or "error" in str(details.get("raw_output", "")).lower():
        st.error("🚨 Error Detected in This Run")
        if isinstance(details.get("parsed_output"), dict):
            err = details["parsed_output"].get("error")
            if err:
                st.code(err, language="bash")

    # Show logs if path exists
    if "log_path" in details and Path(details["log_path"]).exists():
        with open(details["log_path"], "r") as f:
            logs = f.read()
        st.markdown("#### 🧾 Execution Logs")
        st.code(logs, language="bash")

# --- Alert Summary ---
st.markdown("### 📦 Alert to Agent Chain Map")

alert_summary = (
    filtered_df.groupby("alert_id")
    .agg(
        agents_involved=("agent", lambda x: ", ".join(sorted(set(x)))),
        total_runs=("run_id", "count"),
        last_run=("timestamp", "max"),
    )
    .reset_index()
)
st.dataframe(
    alert_summary.style.format(
        {"last_run": lambda t: t.strftime("%Y-%m-%d %H:%M:%S")}
    ),
    use_container_width=True,
)

# --- Footer ---
st.markdown("---")
st.caption("🧩 *CPG AI Admin Portal — Agent Trace Inspector*")
