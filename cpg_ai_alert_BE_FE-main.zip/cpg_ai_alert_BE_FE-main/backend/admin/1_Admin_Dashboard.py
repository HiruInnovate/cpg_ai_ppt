import os
import json
from pathlib import Path
import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime

# ---- Page Config ----
st.set_page_config(page_title="Agent Monitoring Dashboard", layout="wide", page_icon="📊")
st.title("📊 Agent Monitoring Dashboard")
st.caption("Monitor and trace AI Agent executions, orchestration errors, and runtimes")

# ---- Load Data ----
agent_runs_path = "../data/json_store/agent_runs.json"

if not os.path.exists(agent_runs_path):
    st.error("❌ agent_runs.json not found in json_store directory.")
    st.stop()

with open(agent_runs_path, "r", encoding="utf-8") as f:
    data = json.load(f)

if not data:
    st.warning("⚠️ No agent run data available yet.")
    st.stop()

df = pd.DataFrame(data)
df["timestamp"] = pd.to_datetime(df["timestamp"])
df = df.sort_values("timestamp", ascending=False)

# ---- Sidebar Filters ----
st.sidebar.header("🔍 Filters")
agents = sorted(df["agent"].unique())
selected_agents = st.sidebar.multiselect("Select Agent(s)", agents, default=agents)
alerts = sorted(df["alert_id"].unique())
selected_alerts = st.sidebar.multiselect("Select Alert(s)", alerts, default=alerts)

filtered_df = df[df["agent"].isin(selected_agents) & df["alert_id"].isin(selected_alerts)]

# ---- Summary Metrics ----
st.markdown("### 📈 Overall Run Statistics")
col1, col2, col3, col4 = st.columns(4)
col1.metric("Total Runs", len(filtered_df))
col2.metric("Unique Agents", len(filtered_df["agent"].unique()))
col3.metric("Unique Alerts", len(filtered_df["alert_id"].unique()))
error_runs = filtered_df[filtered_df["agent"].str.contains("Error", case=False)]
col4.metric("Error Runs", len(error_runs))

# ---- Timeline Visualization ----
st.markdown("### 🕒 Agent Activity Timeline")
fig_timeline = px.scatter(
    filtered_df,
    x="timestamp",
    y="agent",
    color=filtered_df["agent"].apply(lambda x: "Error" if "Error" in x else "Normal"),
    hover_data=["run_id", "alert_id", "input", "raw_output"],
    title="Agent Run Activity Over Time",
    color_discrete_map={"Error": "red", "Normal": "blue"},
    size_max=10,
)
fig_timeline.update_traces(marker=dict(symbol="circle", opacity=0.8))
fig_timeline.update_layout(
    xaxis_title="Timestamp",
    yaxis_title="Agent",
    height=400,
    margin=dict(l=20, r=20, t=60, b=40),
)
st.plotly_chart(fig_timeline, use_container_width=True)

# ---- Error Analysis ----
st.markdown("### ⚠️ Error Distribution")
error_counts = df[df["agent"].str.contains("Error", case=False)]["parsed_output"].apply(
    lambda x: str(x.get("error", "Unknown")) if isinstance(x, dict) else "Unknown").value_counts().reset_index()
error_counts.columns = ["Error Type", "Count"]

if not error_counts.empty:
    fig_error = px.bar(
        error_counts,
        x="Error Type",
        y="Count",
        title="Top Agent Errors",
        color="Count",
        color_continuous_scale="Reds",
    )
    fig_error.update_layout(height=400, xaxis_title="Error Message", yaxis_title="Occurrences")
    st.plotly_chart(fig_error, use_container_width=True)
else:
    st.info("✅ No error runs detected.")

# ---- Agent Performance Summary ----
st.markdown("### 🤖 Agent Performance Summary")
performance_summary = (
    filtered_df.groupby("agent")
    .agg(
        total_runs=("run_id", "count"),
        unique_alerts=("alert_id", "nunique"),
        last_run=("timestamp", "max")
    )
    .reset_index()
    .sort_values("total_runs", ascending=False)
)

st.dataframe(
    performance_summary.style.format(
        {"last_run": lambda t: t.strftime("%Y-%m-%d %H:%M:%S")}
    ),
    use_container_width=True,
)

# ---- Agent Run Explorer ----
st.markdown("### 🔍 Detailed Agent Run Explorer")

with st.expander("View Agent Runs Table"):
    st.dataframe(
        filtered_df[[
            "run_id",
            "agent",
            "alert_id",
            "timestamp",
            "input",
            "raw_output"
        ]],
        use_container_width=True,
    )

# ---- Drill-down Viewer ----
st.markdown("### 🧠 Inspect Agent Run Details")
selected_run = st.selectbox("Select a Run ID to Inspect", filtered_df["run_id"].tolist())

run_data = filtered_df[filtered_df["run_id"] == selected_run].iloc[0]
st.markdown(f"**Agent:** `{run_data['agent']}`")
st.markdown(f"**Alert ID:** `{run_data['alert_id']}`")
st.markdown(f"**Timestamp:** `{run_data['timestamp']}`")

st.markdown("#### 🧩 Input Command")
st.code(run_data["input"], language="bash")

st.markdown("#### 🧮 Raw Output")
st.code(run_data["raw_output"], language="json")

if isinstance(run_data["parsed_output"], dict) and run_data["parsed_output"]:
    st.markdown("#### 🧾 Parsed Output JSON")
    st.json(run_data["parsed_output"])

# ---- Alerts Overview ----
st.markdown("### 🚨 Alert-Linked Agent Runs Summary")
alert_summary = (
    filtered_df.groupby("alert_id")
    .agg(
        agents_involved=("agent", lambda x: list(sorted(set(x)))),
        total_runs=("run_id", "count"),
        last_run=("timestamp", "max")
    )
    .reset_index()
)
alert_summary["agents_involved"] = alert_summary["agents_involved"].apply(lambda lst: ", ".join(lst))

st.dataframe(
    alert_summary.style.format(
        {"last_run": lambda t: t.strftime("%Y-%m-%d %H:%M:%S")}
    ),
    use_container_width=True,
)

# ---- Footer ----
st.markdown("---")
st.caption("🧩 *CPG AI Admin Portal — Agent Observability Dashboard*")
