import os
import json
from pathlib import Path
import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime

# --- Page Config ---
st.set_page_config(page_title="LLM Agent Evaluation (RAGAS)", layout="wide", page_icon="🧠")
st.title("🧠 LLM Agent Evaluation (RAGAS)")
st.caption("Evaluate agent performance on RAGAS metrics — faithfulness, precision, and relevancy.")

# --- Load Data ---
ragas_path = "../data/json_store/ragas_summary.json"

if not os.path.exists(ragas_path):
    st.error("❌ ragas_metrics.json not found in json_store directory.")
    st.stop()

with open(ragas_path, "r", encoding="utf-8") as f:
    data = json.load(f)

if not data:
    st.warning("⚠️ No evaluation data available.")
    st.stop()

df = pd.DataFrame(data)
df["timestamp"] = pd.to_datetime(df["timestamp"])
df = df.sort_values("timestamp", ascending=False)

# --- Sidebar Filters ---
st.sidebar.header("🔍 Filters")
agents = sorted(df["agent_name"].unique())
selected_agents = st.sidebar.multiselect("Select Agent(s)", agents, default=agents)

filtered_df = df[df["agent_name"].isin(selected_agents)]

# --- Summary Section ---
st.markdown("### 📊 Evaluation Summary")
col1, col2, col3, col4 = st.columns(4)
col1.metric("Total Evaluations", len(filtered_df))
col2.metric("Unique Agents", len(filtered_df["agent_name"].unique()))
col3.metric("Avg Faithfulness", f"{filtered_df['faithfulness'].mean():.2f}")
col4.metric("Avg Answer Relevancy", f"{filtered_df['answer_relevancy'].mean():.2f}")

# --- Metric Distribution ---
st.markdown("### 🎯 Metric Comparison by Agent")
metric_long = filtered_df.melt(
    id_vars=["agent_name", "timestamp"],
    value_vars=["faithfulness", "context_precision", "answer_relevancy"],
    var_name="metric",
    value_name="score"
)

fig_bar = px.bar(
    metric_long,
    x="agent_name",
    y="score",
    color="metric",
    barmode="group",
    text_auto=".2f",
    title="Average RAGAS Metric Breakdown by Agent",
    color_discrete_sequence=["#2563eb", "#10b981", "#9333ea"]
)
fig_bar.update_layout(
    height=450,
    xaxis_title="Agent Name",
    yaxis_title="Metric Score",
    yaxis=dict(range=[0, 1]),
)
st.plotly_chart(fig_bar, use_container_width=True)

# --- Trend Over Time ---
st.markdown("### 📈 Temporal Performance Trends")
fig_line = px.line(
    filtered_df,
    x="timestamp",
    y=["faithfulness", "context_precision", "answer_relevancy"],
    color_discrete_sequence=["#2563eb", "#10b981", "#9333ea"],
    title="Metric Trends Over Time",
)
fig_line.update_layout(height=450, xaxis_title="Timestamp", yaxis_title="Score (0-1)")
st.plotly_chart(fig_line, use_container_width=True)

# --- Agent Summary Table ---
st.markdown("### 🧠 Agent-Level Summary")

summary = (
    filtered_df.groupby("agent_name")
    .agg(
        total_runs=("agent_name", "count"),
        avg_faithfulness=("faithfulness", "mean"),
        avg_precision=("context_precision", "mean"),
        avg_relevancy=("answer_relevancy", "mean"),
        last_eval=("timestamp", "max"),
    )
    .reset_index()
)
summary = summary.round(3)
summary = summary.sort_values("avg_faithfulness", ascending=False)

st.dataframe(
    summary.style.format(
        {"last_eval": lambda t: t.strftime("%Y-%m-%d %H:%M:%S")}
    ),
    use_container_width=True,
)

# --- Detailed Record Explorer ---
st.markdown("### 🔍 Detailed Evaluation Records")
selected_agent = st.selectbox("Select Agent for Detail View", sorted(filtered_df["agent_name"].unique()))
agent_records = filtered_df[filtered_df["agent_name"] == selected_agent].sort_values("timestamp", ascending=False)

if not agent_records.empty:
    with st.expander(f"📑 View All Evaluations for `{selected_agent}`", expanded=True):
        st.dataframe(
            agent_records[
                ["timestamp", "faithfulness", "context_precision", "answer_relevancy"]
            ],
            use_container_width=True,
        )

    st.markdown(f"### 🧩 Latest Evaluation — `{selected_agent}`")
    latest = agent_records.iloc[0]
    colA, colB, colC = st.columns(3)
    colA.metric("Faithfulness", f"{latest['faithfulness']:.3f}")
    colB.metric("Context Precision", f"{latest['context_precision']:.3f}")
    colC.metric("Answer Relevancy", f"{latest['answer_relevancy']:.3f}")

    # Radar Chart for latest evaluation
    radar_fig = go.Figure()
    categories = ["Faithfulness", "Context Precision", "Answer Relevancy"]
    values = [
        latest["faithfulness"],
        latest["context_precision"],
        latest["answer_relevancy"],
    ]
    radar_fig.add_trace(go.Scatterpolar(
        r=values + [values[0]],
        theta=categories + [categories[0]],
        fill="toself",
        name=selected_agent,
        line_color="#6366f1"
    ))
    radar_fig.update_layout(
        polar=dict(radialaxis=dict(visible=True, range=[0, 1])),
        showlegend=False,
        title="Performance Radar (Latest Evaluation)",
        height=400,
    )
    st.plotly_chart(radar_fig, use_container_width=True)

# --- Footer ---
st.markdown("---")
st.caption("🧩 *CPG AI Admin Portal — RAGAS Evaluation Dashboard*")
