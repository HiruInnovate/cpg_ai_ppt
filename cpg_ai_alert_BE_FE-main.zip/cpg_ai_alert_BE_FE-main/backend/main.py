from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.routers import ws_router, vision_router
from backend.routers import alerts, rca_agent, impact_agent, ragas, data_integrator, chat_agent_router

app = FastAPI(title="CPG AI Alerting System", version="1.0")

# ✅ Enable CORS for your React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For dev: use "*" | In prod, specify your React domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ✅ Include routers
app.include_router(alerts.router, prefix="/alerts", tags=["Alerts"])
app.include_router(rca_agent.router, prefix="/rca", tags=["RCA Agent"])
app.include_router(impact_agent.router, prefix="/impact", tags=["Impact Agent"])
app.include_router(ragas.router, prefix="/evaluate", tags=["Evaluation"])
app.include_router(data_integrator.router, prefix="/data", tags=["Data Integrator"])
app.include_router(chat_agent_router.router, prefix="/chat", tags=["Chat Agent"])

app.include_router(ws_router.router)
app.include_router(vision_router.router)


@app.get("/")
def root():
    return {"message": "CPG AI Alert Backend is running"}
