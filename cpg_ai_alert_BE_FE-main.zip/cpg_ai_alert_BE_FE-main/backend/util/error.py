from typing import Optional


def error_response(message: str, details: Optional[str] = None) -> dict:
    return {
        "error": True,
        "message": message,
        "details": details,
    }