import asyncio
import time
import os
import traceback
from typing import Callable, Any, Optional
from fastapi import HTTPException
from backend.services.logger_config import get_logger

logger = get_logger(__name__)

MAX_RETRY_ATTEMPTS = int(os.getenv("AGENT_MAX_RETRIES", 3))
INITIAL_BACKOFF = float(os.getenv("AGENT_RETRY_DELAY", 1.0))


def _is_error_response(result: Any) -> bool:
    """
    Check if a function result follows the uniform error schema.
    Expected structure: {"error": True, "message": "..."}
    """
    return isinstance(result, dict) and result.get("error") is True


def _max_attempts_failed(func_name: str, last_error: str = None):
    """
    Standardized final error response once all retries are exhausted.
    """
    msg = f"All retry attempts failed for {func_name}"
    if last_error:
        msg += f" — last error: {last_error}"
    logger.error(f"[RETRY][{func_name}] {msg}")
    # Return an HTTPException-compatible dict for routers to raise or return
    return {
        "error": True,
        "message": msg,
        "status_code": 500,
    }


# ------------------------------------------------------------------------------
# Async Retry
# ------------------------------------------------------------------------------
async def retry_async(
    func: Callable[..., Any],
    *args,
    max_attempts: Optional[int] = None,
    backoff: float = INITIAL_BACKOFF,
    retry_exceptions: tuple = (Exception,),
    **kwargs,
) -> Any:
    """
    Retry async functions with exponential backoff.
    Automatically retries on:
      - Exceptions
      - Structured error responses {"error": True, "message": ...}
    Returns:
      - Successful result on success
      - {"error": True, "status_code": 500} when max retries exhausted
    """
    max_attempts = max_attempts or MAX_RETRY_ATTEMPTS
    delay = backoff
    last_err_msg = None

    for attempt in range(1, max_attempts + 1):
        try:
            result = await func(*args, **kwargs)

            # Structured error response handling
            if _is_error_response(result):
                last_err_msg = result.get("message")
                logger.warning(
                    f"[RETRY][{func.__name__}] Attempt {attempt}/{max_attempts} "
                    f"returned error: {last_err_msg}"
                )
                if attempt == max_attempts:
                    return _max_attempts_failed(func.__name__, last_err_msg)
                await asyncio.sleep(delay)
                delay *= 2
                continue

            # ✅ Success
            return result

        except retry_exceptions as e:
            last_err_msg = str(e)
            logger.warning(
                f"[RETRY][{func.__name__}] Attempt {attempt}/{max_attempts} failed with exception: {e}"
            )
            traceback.print_exc()
            if attempt == max_attempts:
                return _max_attempts_failed(func.__name__, last_err_msg)
            await asyncio.sleep(delay)
            delay *= 2


# ------------------------------------------------------------------------------
# Sync Retry
# ------------------------------------------------------------------------------
def retry_sync(
    func: Callable[..., Any],
    *args,
    max_attempts: Optional[int] = None,
    backoff: float = INITIAL_BACKOFF,
    retry_exceptions: tuple = (Exception,),
    **kwargs,
) -> Any:
    """
    Retry synchronous functions with exponential backoff.
    Automatically retries on:
      - Exceptions
      - Structured error responses {"error": True, "message": ...}

    Returns:
      - Successful result on success
      - {"error": True, "status_code": 500} when max retries exhausted
    """
    max_attempts = max_attempts or MAX_RETRY_ATTEMPTS
    delay = backoff
    last_err_msg = None

    for attempt in range(1, max_attempts + 1):
        try:
            result = func(*args, **kwargs)

            # Structured error response check
            if _is_error_response(result):
                last_err_msg = result.get("message")
                logger.warning(
                    f"[RETRY][{func.__name__}] Attempt {attempt}/{max_attempts} returned error: {last_err_msg}"
                )
                if attempt == max_attempts:
                    return _max_attempts_failed(func.__name__, last_err_msg)
                time.sleep(delay)
                delay *= 2
                continue

            # ✅ Success
            return result

        except retry_exceptions as e:
            last_err_msg = str(e)
            logger.warning(
                f"[RETRY][{func.__name__}] Attempt {attempt}/{max_attempts} failed with exception: {e}"
            )
            traceback.print_exc()
            if attempt == max_attempts:
                return _max_attempts_failed(func.__name__, last_err_msg)
            time.sleep(delay)
            delay *= 2
