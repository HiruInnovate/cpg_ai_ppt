import base64
import io
from PIL import Image
from backend.services.logger_config import get_logger

logger = get_logger(__name__)


def decode_base64_image(base64_str: str) -> Image.Image:
    """
    Decodes a base64 image string into a PIL Image object.
    """
    try:
        header, encoded = base64_str.split(",", 1) if "," in base64_str else ("", base64_str)
        img_bytes = base64.b64decode(encoded)
        image = Image.open(io.BytesIO(img_bytes))
        logger.info("[IMAGE_UTILS] Image decoded successfully")
        return image
    except Exception as e:
        logger.error(f"[IMAGE_UTILS] Failed to decode base64 image: {e}", exc_info=True)
        raise ValueError("Invalid base64 image data.")
