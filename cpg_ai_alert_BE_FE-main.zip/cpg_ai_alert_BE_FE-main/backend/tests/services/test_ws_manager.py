"""
Unit tests for WebSocketManager.
We mock FastAPI WebSocket and test connect, send, disconnect and broadcast flows.
"""

import pytest
import json
from unittest.mock import AsyncMock, MagicMock
from backend.services.ws_manager import WebSocketManager


@pytest.mark.asyncio
async def test_connect_and_disconnect():
    """Should add and remove websocket properly from active_connections."""
    manager = WebSocketManager()
    ws = AsyncMock()
    await manager.connect(ws, "session_1")
    assert "session_1" in manager.active_connections
    assert ws in manager.active_connections["session_1"]

    manager.disconnect(ws, "session_1")
    assert ws not in manager.active_connections["session_1"]


@pytest.mark.asyncio
async def test_send_to_session_success():
    """Should send text to all websockets under given session."""
    manager = WebSocketManager()
    ws = AsyncMock()
    await manager.connect(ws, "abc")
    data = {"msg": "hello"}
    await manager.send_to_session("abc", data)

    ws.send_text.assert_called_once_with(json.dumps(data, ensure_ascii=False))


@pytest.mark.asyncio
async def test_send_to_session_with_error_removes_dead_socket():
    """If send_text raises error, it should remove that socket."""
    manager = WebSocketManager()
    ws = AsyncMock()
    ws.send_text.side_effect = Exception("socket broken")
    await manager.connect(ws, "s1")

    await manager.send_to_session("s1", {"msg": "hi"})
    # should disconnect the dead websocket
    assert ws not in manager.active_connections["s1"]


@pytest.mark.asyncio
async def test_broadcast_calls_all_sessions():
    """Should broadcast data to all sessions."""
    manager = WebSocketManager()
    ws1, ws2 = AsyncMock(), AsyncMock()
    await manager.connect(ws1, "s1")
    await manager.connect(ws2, "s2")

    data = {"info": "system maintenance"}
    await manager.broadcast(data)

    ws1.send_text.assert_called_once()
    ws2.send_text.assert_called_once()
