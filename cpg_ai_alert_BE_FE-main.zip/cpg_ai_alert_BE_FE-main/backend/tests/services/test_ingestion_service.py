"""
Test cases for file ingestion service.
We use mocks for filesystem and index_text to avoid real writes or DB work.
"""

import pytest
import os
from unittest.mock import patch, MagicMock, AsyncMock
from fastapi import UploadFile, HTTPException
from backend.services import ingestion as svc


@pytest.mark.asyncio
async def test_save_upload_creates_file(tmp_path):
    """Check if save_upload writes file chunks properly."""
    mock_upload = AsyncMock(spec=UploadFile)
    mock_upload.filename = "sample.txt"
    mock_upload.read = AsyncMock(side_effect=[b"data", b""])
    mock_upload.close = AsyncMock()

    svc.FEED_DIR = str(tmp_path)

    result_path = await svc.save_upload(mock_upload)
    assert os.path.exists(result_path)
    assert result_path.startswith(str(tmp_path))


@pytest.mark.asyncio
async def test_save_upload_exceeds_limit(tmp_path):
    """File exceeding limit should raise HTTPException."""
    mock_upload = AsyncMock(spec=UploadFile)
    mock_upload.filename = "big.txt"
    mock_upload.read = AsyncMock(side_effect=[b"x" * (210 * 1024 * 1024)])  # 210 MB fake data
    mock_upload.close = AsyncMock()

    svc.FEED_DIR = str(tmp_path)

    with pytest.raises(HTTPException):
        await svc.save_upload(mock_upload)


@patch("backend.services.ingestion_service.smart_normalize")
@patch("backend.services.ingestion_service.load_json")
@patch("backend.services.ingestion_service.overwrite_json")
@patch("backend.services.ingestion_service.index_text")
def test_process_file_shipment(mock_index, mock_overwrite, mock_load, mock_normalize):
    """Shipment type file should store JSON and not fail."""
    mock_normalize.return_value = {"type": "shipment_events", "items": [{"id": 1}]}
    mock_load.return_value = []
    result = svc.process_file("dummy.json")
    assert result["type"] == "shipment_events"
    mock_overwrite.assert_called_once()


@patch("backend.services.ingestion_service.smart_normalize")
@patch("backend.services.ingestion_service.index_text", return_value=5)
def test_process_file_news(mock_index, mock_norm):
    """News file should trigger vector indexing."""
    mock_norm.return_value = {"type": "news_articles", "items": [{"id": "n1", "text": "hello"}]}
    result = svc.process_file("news.json")
    assert result["indexed"] == 5
    assert result["namespace"] == "news_data"


@patch("backend.services.ingestion_service.smart_normalize")
def test_process_file_unknown_type(mock_norm):
    """Unknown file type should return warning dict."""
    mock_norm.return_value = {"type": "weird", "items": []}
    result = svc.process_file("abc.json")
    assert result["type"] == "unknown"


@patch("backend.services.ingestion_service.smart_normalize", side_effect=Exception("Bad data"))
def test_process_file_error(mock_norm):
    """If normalizer fails, error dict should return."""
    result = svc.process_file("error.json")
    assert "error" in result
    assert result["type"] == "error"
