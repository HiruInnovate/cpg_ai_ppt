
"""
Unit tests for LLM Factory module.
These tests verify that correct models and configurations are returned.
We mock ChatOpenAI, OpenAIEmbeddings, and OpenAI client so no real API call happen.
"""

import pytest
from unittest.mock import patch, MagicMock
import backend.services.llm_factory as factory


@patch("backend.services.llm_factory.ChatOpenAI")
def test_create_chat_model_openai(mock_chat):
    """Chat model created using OpenAI path should work."""
    mock_chat.return_value = MagicMock()
    result = factory.create_chat_model()
    assert result is not None
    mock_chat.assert_called_once()


@patch("backend.services.llm_factory.ChatOpenAI")
def test_create_chat_model_agent_mode(mock_chat):
    """Agent mode chat should include stop tokens."""
    mock_chat.return_value = MagicMock()
    result = factory.create_chat_model(is_agent=True)
    assert result is not None
    args, kwargs = mock_chat.call_args
    assert "stop" in kwargs


@patch("backend.services.llm_factory.OpenAIEmbeddings")
def test_create_embedding_model(mock_embed):
    """Embedding model creation returns valid object."""
    mock_embed.return_value = MagicMock()
    emb = factory.create_embedding_model()
    assert emb is not None
    mock_embed.assert_called_once()


@patch("backend.services.llm_factory.create_chat_model")
@patch("backend.services.llm_factory.create_embedding_model")
def test_llm_factory_test_success(mock_emb, mock_chat):
    """If chat and emb creation works, function should return True."""
    mock_chat.return_value.invoke.return_value = MagicMock(content="ok")
    mock_emb.return_value = MagicMock()
    assert factory.test_llm_factory() is True


@patch("backend.services.llm_factory.create_chat_model", side_effect=Exception("Fail"))
def test_llm_factory_test_failure(mock_chat):
    """Failure in LLM init should return False."""
    assert factory.test_llm_factory() is False


@patch("backend.services.llm_factory.OpenAI")
def test_create_vision_model(mock_openai):
    """Vision model creation returns tuple (client, model_name)."""
    fake_client = MagicMock()
    mock_openai.return_value = fake_client
    client, model = factory.create_vision_model("gpt-4o")
    assert client == fake_client
    assert model == "gpt-4o"
    mock_openai.assert_called_once()
