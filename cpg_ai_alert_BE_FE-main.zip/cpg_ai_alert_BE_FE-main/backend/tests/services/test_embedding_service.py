"""
These tests check if the embedding and chroma functions are working fine.
We mock heavy components like OpenAIEmbeddings and Chroma to keep test fast and light.

Focus:
- ensure model initialization not fail
- index_text return valid count
- get_retrievers gives dict back
"""

import pytest
from unittest.mock import patch, MagicMock
import backend.services.llm_factory as emb_module


@patch("backend.services.llm_factory.OpenAIEmbeddings")
def test_create_embedding_model_openai(mock_embed_class):
    """Check if embedding model initialize properly for OpenAI mode."""
    mock_embed_class.return_value = MagicMock()
    model = emb_module.create_embedding_model()
    assert model is not None
    mock_embed_class.assert_called_once()


@patch("backend.services.llm_factory.Chroma")
def test_index_text_success(mock_chroma):
    """Simulate indexing text and ensure it counts chunks properly."""
    fake_db = MagicMock()
    mock_chroma.return_value = fake_db
    fake_db.add_texts.return_value = None

    docs = [{"id": "1", "text": "sample small text"}]
    count = emb_module.index_text(docs, "test_ns")
    assert count > 0
    fake_db.add_texts.assert_called_once()


@patch("backend.services.llm_factory.Chroma")
def test_index_text_invalid_docs(mock_chroma):
    """Invalid doc list should not fail and return 0 chunks."""
    mock_chroma.return_value = MagicMock()
    result = emb_module.index_text([{"bad": "doc"}])
    assert result == 0


@patch("backend.services.llm_factory.Chroma")
def test_get_retrievers_success(mock_chroma):
    """Test retrievers creation for multiple namespaces."""
    mock_db = MagicMock()
    mock_chroma.return_value = mock_db
    mock_db.as_retriever.return_value = "retriever"

    retrievers = emb_module.get_retrievers()
    assert isinstance(retrievers, dict)
    assert "news_data" in retrievers
    assert all(isinstance(v, str) for v in retrievers.values())


@patch("backend.services.llm_factory.Chroma", side_effect=Exception("DB init fail"))
def test_get_retrievers_handles_error(mock_chroma):
    """Check error handling if chroma creation fails."""
    retrievers = emb_module.get_retrievers()
    assert isinstance(retrievers, dict)
    assert len(retrievers) == 0
