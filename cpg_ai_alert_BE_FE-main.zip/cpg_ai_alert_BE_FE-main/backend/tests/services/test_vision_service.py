"""
Tests for VisionService.
We mock OpenAI client to test behavior without real API calls.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from backend.services.vision_service import VisionService


@pytest.mark.asyncio
@patch("backend.services.vision_service.create_vision_model")
async def test_analyze_image_success(mock_create):
    """Should return success when model responds correctly."""
    # Mock OpenAI client and response
    mock_client = MagicMock()
    mock_response = MagicMock()
    mock_choice = MagicMock()
    mock_choice.message.content = "Detected text: Invoice #123"
    mock_response.choices = [mock_choice]
    mock_client.chat.completions.create.return_value = mock_response

    mock_create.return_value = (mock_client, "gpt-4o-mini")

    service = VisionService()
    result = await service.analyze_image("fake_base64_string", "Read the text from image")

    assert result["status"] == "success"
    assert "Detected" in result["output"]
    mock_client.chat.completions.create.assert_called_once()


@pytest.mark.asyncio
@patch("backend.services.vision_service.create_vision_model")
async def test_analyze_image_failure(mock_create):
    """Should return error when exception occurs."""
    mock_client = MagicMock()
    mock_client.chat.completions.create.side_effect = Exception("API failed")

    mock_create.return_value = (mock_client, "gpt-4o-mini")
    service = VisionService()

    result = await service.analyze_image("base64", "extract text")
    assert result["status"] == "error"
    assert "API failed" in result["message"]
