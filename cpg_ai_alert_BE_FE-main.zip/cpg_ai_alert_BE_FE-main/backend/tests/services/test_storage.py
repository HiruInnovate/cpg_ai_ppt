"""
Unit tests for JSON storage utility.
We test load, save, append and overwrite functions with temporary files.
"""

import json
import os
import pytest
from backend.services import storage


def test_save_and_load_json(tmp_path):
    """Should save and then load the same JSON data correctly."""
    data = [{"id": 1, "name": "test"}]
    fn = "sample.json"
    storage._path = lambda f: str(tmp_path / f)

    storage.save_json(fn, data)
    loaded = storage.load_json(fn)
    assert loaded == data


def test_load_json_nonexistent(tmp_path):
    """Should return [] for missing file."""
    storage._path = lambda f: str(tmp_path / f)
    result = storage.load_json("nofile.json")
    assert result == []


def test_load_json_broken_file(tmp_path):
    """Should handle invalid JSON gracefully."""
    path = tmp_path / "bad.json"
    path.write_text("{bad json}")
    storage._path = lambda f: str(path)
    result = storage.load_json("bad.json")
    assert result == []


def test_append_json_creates_file(tmp_path):
    """Append should create new file if not exists."""
    fn = "append.json"
    storage._path = lambda f: str(tmp_path / f)
    obj = {"id": 2}
    storage.append_json(fn, obj)
    data = json.load(open(tmp_path / fn))
    assert data[0]["id"] == 2


def test_append_json_to_existing(tmp_path):
    """Should append to an existing list file."""
    fn = "existing.json"
    file_path = tmp_path / fn
    json.dump([{"id": 1}], open(file_path, "w"))
    storage._path = lambda f: str(file_path)
    storage.append_json(fn, {"id": 2})
    data = json.load(open(file_path))
    assert len(data) == 2


def test_append_json_nonlist(tmp_path):
    """If file content is not list, it should reset it."""
    fn = "object.json"
    file_path = tmp_path / fn
    json.dump({"key": "value"}, open(file_path, "w"))
    storage._path = lambda f: str(file_path)
    storage.append_json(fn, {"id": 5})
    data = json.load(open(file_path))
    assert isinstance(data, list)


def test_overwrite_json_replaces_content(tmp_path):
    """Should overwrite file content completely."""
    fn = "overwrite.json"
    storage._path = lambda f: str(tmp_path / f)
    storage.save_json(fn, [{"old": 1}])
    storage.overwrite_json(fn, [{"new": 2}])
    data = json.load(open(tmp_path / fn))
    assert "new" in data[0]
