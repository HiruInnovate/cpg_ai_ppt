"""
Tests for custom logger setup.

We mainly check that:
 - logger is returned properly
 - it avoids duplicate handlers
 - SafeRotatingFileHandler handles rollover without crash
"""

import os
import pytest
import logging
from unittest.mock import patch, MagicMock
from backend.services import logger_config as lc


def test_get_logger_creates_logger(tmp_path):
    """Check that get_logger returns a proper logger with file + console handler."""
    log_dir = tmp_path / "logs"
    os.makedirs(log_dir, exist_ok=True)
    lc.LOG_DIR = str(log_dir)
    lc.LOG_PATH = str(log_dir / "app.log")

    logger = lc.get_logger("test_logger")

    assert isinstance(logger, logging.Logger)
    assert len(logger.handlers) >= 2
    assert any(isinstance(h, lc.SafeRotatingFileHandler) for h in logger.handlers)
    assert os.path.exists(lc.LOG_PATH)


def test_get_logger_no_duplicate_handlers(tmp_path):
    """Calling get_logger twice should not add duplicate handlers."""
    lc.LOG_PATH = str(tmp_path / "app.log")
    logger1 = lc.get_logger("dupe_logger")
    first_count = len(logger1.handlers)

    logger2 = lc.get_logger("dupe_logger")
    second_count = len(logger2.handlers)

    assert first_count == second_count  # same handler count, no duplication


def test_safe_rollover_permissionerror(monkeypatch, tmp_path, capsys):
    """If rollover faces PermissionError, should print fallback message instead of crash."""
    fake_file = tmp_path / "app.log"
    fake_file.write_text("some log content")
    handler = lc.SafeRotatingFileHandler(str(fake_file), maxBytes=1, backupCount=1)

    # Simulate permission error on super().doRollover
    def fake_rollover():
        raise PermissionError("file locked")

    monkeypatch.setattr(logging.handlers.RotatingFileHandler, "doRollover", fake_rollover)

    handler.doRollover()
    out = capsys.readouterr().out
    assert "[LOGGER]" in out  # fallback message printed


def test_safe_rollover_fails_copy(monkeypatch, capsys, tmp_path):
    """Even if both rename and copy fails, it should not crash the process."""
    fake_file = tmp_path / "app.log"
    fake_file.write_text("something")
    handler = lc.SafeRotatingFileHandler(str(fake_file), maxBytes=1, backupCount=1)

    def fake_copy(src, dest):
        raise Exception("copy failed")

    with patch("shutil.copy", side_effect=fake_copy):
        handler.doRollover()
        out = capsys.readouterr().out
        assert "Rollover failed" in out
