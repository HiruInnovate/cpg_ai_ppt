"""
Tests for smart_normalize function.
These tests cover CSV, JSON, TXT, and unknown file handling.
"""

import json
import pandas as pd
import pytest
from pathlib import Path
from backend.services.normalizer import smart_normalize


def make_csv(tmp_path, cols, rows):
    file_path = tmp_path / "data.csv"
    df = pd.DataFrame(rows, columns=cols)
    df.to_csv(file_path, index=False)
    return file_path


def make_json(tmp_path, content):
    file_path = tmp_path / "data.json"
    json.dump(content, open(file_path, "w", encoding="utf-8"))
    return file_path


def make_txt(tmp_path, content):
    file_path = tmp_path / "data.txt"
    file_path.write_text(content, encoding="utf-8")
    return file_path


def test_normalize_csv_shipment(tmp_path):
    """Should classify shipment_events from CSV."""
    file = make_csv(tmp_path, ["shipment_id", "sku"], [["SHP1", "X"]])
    result = smart_normalize(str(file))
    assert result["type"] == "shipment_events"
    assert len(result["items"]) == 1


def test_normalize_csv_news(tmp_path):
    """Should classify news_articles from CSV."""
    file = make_csv(tmp_path, ["headline", "body"], [["Title1", "Content"]])
    result = smart_normalize(str(file))
    assert result["type"] == "news_articles"
    assert result["items"][0]["id"].startswith("news_")


def test_normalize_csv_social(tmp_path):
    """Should classify social_posts from CSV."""
    file = make_csv(tmp_path, ["post"], [["Nice product"]])
    result = smart_normalize(str(file))
    assert result["type"] == "social_posts"
    assert "Nice" in result["items"][0]["text"]


def test_normalize_json_shipment(tmp_path):
    """Should detect shipment_events from JSON."""
    file = make_json(tmp_path, [{"shipment_id": "SHP1"}])
    result = smart_normalize(str(file))
    assert result["type"] == "shipment_events"


def test_normalize_json_news(tmp_path):
    """Should detect news_articles from JSON."""
    file = make_json(tmp_path, [{"headline": "Big News", "body": "Details"}])
    result = smart_normalize(str(file))
    assert result["type"] == "news_articles"
    assert "Big" in result["items"][0]["text"]


def test_normalize_json_social(tmp_path):
    """Should detect social_posts from JSON."""
    file = make_json(tmp_path, [{"tweet": "Something trending"}])
    result = smart_normalize(str(file))
    assert result["type"] == "social_posts"


def test_normalize_txt_file(tmp_path):
    """Should classify text_doc for TXT files."""
    file = make_txt(tmp_path, "This is random text data.")
    result = smart_normalize(str(file))
    assert result["type"] == "text_doc"
    assert "random" in result["items"][0]["text"]


def test_normalize_unknown_extension(tmp_path):
    """Unknown extension should return type unknown."""
    file = tmp_path / "file.unknown"
    file.write_text("Some data")
    result = smart_normalize(str(file))
    assert result["type"] == "unknown"


def test_normalize_broken_json(tmp_path):
    """Invalid JSON should safely return type error."""
    file = tmp_path / "broken.json"
    file.write_text("{bad json")
    result = smart_normalize(str(file))
    assert result["type"] == "error"
