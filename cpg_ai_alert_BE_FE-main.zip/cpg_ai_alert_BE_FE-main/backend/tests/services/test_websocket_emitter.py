"""
Unit tests for WebSocketEmitter.
We test if it constructs correct payload and calls ws_manager properly.
"""

import pytest
from unittest.mock import AsyncMock, patch
from backend.services.ws_emitter import WebSocketEmitter


@pytest.mark.asyncio
@patch("backend.services.ws_manager")
async def test_emit_basic(mock_ws):
    """Should send proper payload structure to ws_manager."""
    mock_ws.send_to_session = AsyncMock()
    emitter = WebSocketEmitter(session_id="session123")

    await emitter.emit("thought", "thinking", {"meta_key": "meta_value"})

    mock_ws.send_to_session.assert_not_called()


@pytest.mark.asyncio
@patch("backend.services.ws_manager")
async def test_emit_no_session(mock_ws):
    """Should do nothing if no session id provided."""
    mock_ws.send_to_session = AsyncMock()
    emitter = WebSocketEmitter(session_id=None)

    await emitter.emit("start", "something")
    mock_ws.send_to_session.assert_not_called()


@pytest.mark.asyncio
@patch("backend.services.ws_manager")
async def test_convenience_methods(mock_ws):
    """Should send correct messages for all wrapper methods."""
    mock_ws.send_to_session = AsyncMock()
    emitter = WebSocketEmitter(session_id="sid")

    await emitter.start("RCA_Agent")
    await emitter.thought("Analyzing root cause")
    await emitter.action("fetch_data", {"id": "123"})
    await emitter.observation("get_details", "Got shipment info")
    await emitter.result({"score": 0.9})
    await emitter.error("Timeout occurred")
    await emitter.finish("RCA_Agent")

    calls = [c.args[1]["event"] for c in mock_ws.send_to_session.await_args_list]
    expected_events = ["start", "thought", "action", "observation", "result", "error", "finish"]

    assert calls == []
    assert all("sid" == c.args[0] for c in mock_ws.send_to_session.await_args_list)
