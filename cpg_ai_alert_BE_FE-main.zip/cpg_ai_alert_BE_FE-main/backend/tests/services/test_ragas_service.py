"""
Tests for RAGAS evaluation service.
We mock LLM and ragas evaluation to avoid heavy API calls.
"""

import json
import pytest
import pandas as pd
from pathlib import Path
from unittest.mock import patch, MagicMock
from backend.services import ragas_service as ragas


@pytest.fixture
def fake_ragas_store(tmp_path):
    """Creates a dummy agent_ragas_records.json file."""
    data = [
        {
            "agent_name": "RCA_Agent",
            "question": "What caused delay?",
            "contexts": ['{"shipment_id": "SHP1", "carrier": "BlueDart", "remarks": "weather delay"}'],
            "generated_answer": '{"summary": "Delay due to rain", "recommendations": [{"action": "Adjust route"}]}'
        }
    ]
    file_path = tmp_path / "agent_ragas_records.json"
    json.dump(data, open(file_path, "w"), indent=2)
    ragas.RAGAS_STORE = str(file_path)
    ragas.SUMMARY_STORE = str(tmp_path / "ragas_summary.json")
    return file_path


def test_extract_context_text_handles_json():
    """Should clean and flatten JSON-like context."""
    contexts = ['{"shipment_id":"SHP123","carrier":"TCS","remarks":"Bad weather"}']
    result = ragas._extract_context_text(contexts)
    assert "Shipment" in result[0]
    assert "weather" in result[0]


def test_extract_answer_text_json_style():
    """Should extract summary and recommended actions from JSON string."""
    ans = '{"summary": "Late shipment", "recommendations": [{"action": "Contact carrier"}]}'
    text = ragas._extract_answer_text(ans)
    assert "Late shipment" in text
    assert "Contact carrier" in text


def test_extract_answer_text_fallback_text():
    """Should still work for messy text content."""
    ans = "summary: Delay found 'action': 'Investigate'"
    text = ragas._extract_answer_text(ans)
    assert "Delay" in text
    assert "Investigate" in text


def test_preprocess_records_creates_fields():
    """Should build valid ragas dataset dict."""
    recs = [{
        "question": "reason?",
        "contexts": ['{"shipment_id":"SHP1"}'],
        "generated_answer": '{"summary":"Delay due to weather"}'
    }]
    out = ragas._preprocess_records(recs)
    assert all(k in out for k in ["question", "answer", "contexts", "ground_truth"])
    assert isinstance(out["contexts"][0], list)


@patch("backend.services.ragas_service.evaluate")
@patch("backend.services.ragas_service.create_embedding_model")
@patch("backend.services.ragas_service.create_chat_model")
def test_evaluate_ragas_success(mock_chat, mock_embed, mock_eval, fake_ragas_store):
    """Should evaluate and save summary successfully."""
    mock_chat.return_value = MagicMock()
    mock_embed.return_value = MagicMock()

    dummy_result = pd.DataFrame({
        "faithfulness": [0.7],
        "context_precision": [0.8],
        "answer_relevancy": [0.6],
    })

    mock_eval.return_value.to_pandas.return_value = dummy_result

    summary = ragas.evaluate_ragas("RCA_Agent")
    assert summary["agent_name"] == "RCA_Agent"
    assert Path(ragas.SUMMARY_STORE).exists()
    assert "faithfulness" in summary


def test_evaluate_ragas_no_records(tmp_path):
    """Should raise error when agent data missing."""
    data = [{"agent_name": "Other_Agent", "question": "?"}]
    f = tmp_path / "agent_ragas_records.json"
    json.dump(data, open(f, "w"))
    ragas.RAGAS_STORE = str(f)
    with pytest.raises(ValueError):
        ragas.evaluate_ragas("RCA_Agent")
