# backend/api/data_integrator.py
from fastapi import APIRouter, UploadFile, File, HTTPException, status
import os
from starlette.concurrency import run_in_threadpool

from backend.services.ingestion import save_upload, process_file
from backend.services.logger_config import get_logger

router = APIRouter()
logger = get_logger(__name__)


@router.post("/upload")
async def upload_data(file: UploadFile = File(...)):
    """
    Uploads and processes a file for RCA enrichment.
    Supported types: CSV, JSON, TXT.

    - Streams the incoming UploadFile to disk (no large in-memory reads)
    - Runs the blocking `process_file(path)` in a threadpool
    - Cleans up partial files on error
    """

    dest_path = None
    try:
        # Step 1: Save uploaded file to disk (async)
        dest_path = await save_upload(file)
        print(f"File saved to {dest_path}")
        # Step 2: Process the file (blocking work) in a threadpool
        result = await run_in_threadpool(process_file, dest_path)

        # Step 3: Return success response
        return {
            "status": "success",
            "message": "File successfully processed.",
            "filename": os.path.basename(dest_path),
            "result": result
        }

    except HTTPException:
        # re-raise expected HTTP errors
        raise
    except Exception as e:
        logger.error(f"Data Integration failed: {e}", exc_info=True)
        # attempt to cleanup partial file
        try:
            if dest_path and os.path.exists(dest_path):
                os.remove(dest_path)
        except Exception:
            logger.debug("Failed to remove partial upload: %s", dest_path, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error processing file: {str(e)}"
        )
