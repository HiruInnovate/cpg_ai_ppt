import os

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from backend.orchestrators.langgraph_chat_graph import build_chat_flow, load_chat_history
from backend.services.logger_config import get_logger
import traceback

router = APIRouter()
logger = get_logger(__name__)

# Compile chat flow once at startup
chat_flow = build_chat_flow()


class ChatRequest(BaseModel):
    user_id: str
    message: str


@router.post("/query")
async def chat_query(req: ChatRequest):
    """
    Handles chat-based user queries routed through the LangGraph chat orchestrator.
    Includes:
      ✅ graceful error handling
      ✅ fallback chat responses
      ✅ optional debug-friendly logs
    """
    try:
        # --- Prepare chat state ---
        state = {
            "user_id": req.user_id,
            "history": load_chat_history(req.user_id),
            "last_user_message": req.message,
        }

        logger.info(f"[CHAT_ROUTER] New chat query from user={req.user_id}: {req.message[:100]}")

        # --- Run the chat graph orchestrator ---
        new_state = chat_flow.invoke(state)

        # --- Determine final response ---
        final_response = new_state.get("final_response")
        action = new_state.get("decision", {}).get("action")

        if not final_response:
            logger.warning("[CHAT_ROUTER] Chat flow did not produce a valid response.")
            final_response = (
                "I'm sorry, but I couldn’t process that request right now. "
                "Please try rephrasing or asking again."
            )

        return {
            "status": "success",
            "message": final_response,
            "action": action,
        }

    except Exception as e:
        # --- Global fallback handler for chat flow errors ---
        err_msg = str(e)
        trace = traceback.format_exc()
        logger.error(f"[CHAT_ROUTER] Chat flow failed: {err_msg}\n{trace}")

        # --- Friendly fallback message for end users ---
        fallback_responses = [
            "Hmm, I ran into an issue understanding that. Could you try rephrasing?",
            "Sorry, I had a temporary hiccup while processing your query.",
            "That’s unusual — I couldn’t get the right context. Let’s try again!",
            "Apologies, something went wrong while analyzing that. Please retry in a moment.",
        ]

        import random
        fallback_message = random.choice(fallback_responses)

        # --- Return structured error response ---
        return {
            "status": "error",
            "message": fallback_message,
            "error_details": err_msg if os.getenv("APP_DEBUG", "false").lower() == "true" else None,
        }
