from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from backend.services.ws_manager import ws_manager

router = APIRouter(prefix="/ws", tags=["WebSocket"])


@router.websocket("/agent/{session_id}")
async def websocket_endpoint(websocket: WebSocket, session_id: str):
    """
    WebSocket endpoint for UI clients to receive agent reasoning updates.
    Each agent run uses a session_id (like alert_id).
    """
    await ws_manager.connect(websocket, session_id)
    try:
        while True:
            # Optionally receive client messages (e.g., control commands)
            msg = await websocket.receive_text()
            print(f"[WS][Client→Server] {msg}")
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket, session_id)
