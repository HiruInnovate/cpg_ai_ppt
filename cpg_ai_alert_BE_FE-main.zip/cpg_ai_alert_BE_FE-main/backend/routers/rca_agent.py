from fastapi import APIRouter, Query, HTTPException
from backend.agents.rca_agent import run_rca_agent
from backend.services.logger_config import get_logger
from backend.util.retry_handler import retry_sync

router = APIRouter()
logger = get_logger(__name__)


@router.post("/run")
def run_rca(alert: dict, session_id: str = Query(None, description="WebSocket session id")):
    """
    Run the RCA Agent on a given alert.
    Includes:
      - Retry mechanism for transient agent failures
      - Uniform error handling and structured HTTP 500 on max retries
    """

    try:
        alert_id = alert.get("alert_id", "unknown")
        logger.info(f"[RCA] Running RCA Agent for alert {alert_id}")

        # Execute the RCA agent with automatic retrial
        result = retry_sync(run_rca_agent, alert, max_steps=6, session_id=session_id)

        # --- Handle structured error returned by retry handler ---
        if isinstance(result, dict) and result.get("error"):
            logger.error(
                f"[RCA] RCA Agent failed after retries. Message: {result.get('message')}"
            )
            raise HTTPException(
                status_code=result.get("status_code", 500),
                detail=result.get("message", "RCA Agent failed after retries")
            )

        # --- Normal Success Response ---
        logger.info(f"[RCA] RCA Agent completed successfully for alert {alert_id}")
        return {
            "status": "success",
            "message": "RCA Agent analysis completed",
            "alert_id": alert_id,
            "rca": result
        }

    except HTTPException:
        # pass through controlled HTTP errors
        raise

    except Exception as e:
        logger.error(f"[RCA] RCA Agent fatal failure: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"RCA Agent failed due to unexpected error: {str(e)}"
        )
