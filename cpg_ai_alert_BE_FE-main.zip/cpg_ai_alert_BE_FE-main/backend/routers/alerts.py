from fastapi import APIRouter

from backend.services.logger_config import get_logger
from backend.services.storage import load_json

router = APIRouter()
logger = get_logger(__name__)


@router.get("/")
def get_alerts():
    """Return all existing alerts."""
    alerts = load_json("alerts.json")
    return {"alerts": alerts or []}


# @router.post("/scan")
# def scan_for_alerts():
#     """Trigger alert scanning and orchestration."""
#     logger.info("Running monitor agent...")
#     new_alerts = run_monitor_and_orchestrate(verbose=True)
#     return {"message": f"{len(new_alerts)} alerts generated", "alerts": new_alerts}
