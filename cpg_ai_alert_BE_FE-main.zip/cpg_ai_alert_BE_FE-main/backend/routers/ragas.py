from fastapi import APIRouter
from backend.services.ragas_service import evaluate_ragas
from backend.services.logger_config import get_logger

router = APIRouter()
logger = get_logger(__name__)


@router.get("/evaluate")
def evaluate_agent(agent_name: str = "RCA_Agent"):
    """Run RAGAS evaluation and return scores."""
    try:
        result = evaluate_ragas(agent_name)
        return {"status": "success", "summary": result}
    except Exception as e:
        logger.error(f"[RAGAS API] Error: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}
