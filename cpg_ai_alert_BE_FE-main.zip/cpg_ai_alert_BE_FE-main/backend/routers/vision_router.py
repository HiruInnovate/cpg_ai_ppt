# backend/routers/vision_router.py
from fastapi import APIRouter, HTTPException, Body
from backend.services.logger_config import get_logger
from backend.services.vision_service import VisionService
from backend.util.image_utils import decode_base64_image

router = APIRouter(prefix="/vision", tags=["Vision Analysis"])
logger = get_logger(__name__)


@router.post("/analyze")
async def analyze_image(
        payload: dict = Body(..., example={
            "image_base64": "<base64_image_string>",
            "instructions": "Extract text and summarize the content"
        })
):
    """
    Analyze an image using OpenAI Vision API.
    Accepts a base64 image string + natural-language instructions.
    Returns structured text or JSON extracted from image.
    """
    image_b64 = payload.get("image_base64")
    instructions = payload.get("instructions", "Describe what you see in detail.")

    if not image_b64:
        raise HTTPException(status_code=400, detail="Missing base64 image data.")

    try:
        # optional sanity check (verifies image validity)
        decode_base64_image(image_b64)

        service = VisionService()
        result = await service.analyze_image(image_b64, instructions)
        if result["status"] == "error":
            raise HTTPException(status_code=500, detail=result["message"])

        return result
    except Exception as e:
        logger.error(f"[VISION_ROUTER] Image analysis failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))
