from fastapi import APIRouter, HTTPException
from backend.orchestrators.alert_rca_impact_graph import build_flow
from backend.services.logger_config import get_logger
from backend.util.retry_handler import retry_sync

router = APIRouter()
logger = get_logger(__name__)


@router.post("/run")
def run_full_impact_analysis(request: dict):
    """
    Run the full multi-agent orchestration pipeline:
    RCA → Impact → (future communication agent).

    ✅ Includes:
      - Automatic retry on transient errors
      - Structured HTTP 500 response when retries are exhausted
      - Uniform error handling compatible with all agents
    """

    try:
        alert = request.get("alert", {})
        if not alert:
            raise HTTPException(status_code=400, detail="Missing 'alert' in request body")

        alert_id = alert.get("alert_id", "unknown")
        logger.info(f"[ORCHESTRATOR] Starting flow for alert: {alert_id}")

        # --- Build LangGraph Flow ---
        flow = build_flow()

        initial_state = {
            "alert": alert,
            "rca": None,
            "impact": None,
            "recommendations": None,
            "comm_result": None,
            "traces": [],
            "logs": []
        }

        # ----------------------------------------------------------------------
        # Core execution wrapped for retry handling
        # ----------------------------------------------------------------------
        def execute_flow():
            try:
                result_state = flow.invoke(initial_state)
                logger.info("Flow state ==>>>> ", result_state)

                # Handle structured agent error
                if isinstance(result_state, dict) and result_state.get("error"):
                    msg = result_state.get("message", "Flow returned structured error state")
                    logger.warning(f"[ORCHESTRATOR] Flow returned error: {msg}")
                    # Trigger retry
                    raise ValueError(msg)

                return result_state

            except Exception as e:
                logger.error(f"[ORCHESTRATOR] Flow execution failed: {e}", exc_info=True)
                raise  # trigger retry

        # ----------------------------------------------------------------------
        # 🔁 Retry flow execution up to configured attempts
        # ----------------------------------------------------------------------
        result_state = retry_sync(execute_flow, max_attempts=3)

        # ----------------------------------------------------------------------
        # Handle exhausted retries or structured failure
        # ----------------------------------------------------------------------
        if isinstance(result_state, dict) and result_state.get("error"):
            msg = result_state.get("message", "Unknown orchestration failure")
            logger.error(f"[ORCHESTRATOR] Flow failed after retries: {msg}")

            # Raise structured 500 HTTP exception
            raise HTTPException(
                status_code=result_state.get("status_code", 500),
                detail=msg
            )

        # ----------------------------------------------------------------------
        # ✅ Success
        # ----------------------------------------------------------------------
        logger.info(f"[ORCHESTRATOR] Flow completed successfully for alert {alert_id}")

        return {
            "status": "success",
            "message": "RCA + Impact analysis completed successfully",
            "alert_id": alert_id,
            "data": {
                "rca": result_state.get("rca"),
                "impact": result_state.get("impact"),
                "recommendations": result_state.get("recommendations"),
                "traces": result_state.get("traces"),
                "logs": result_state.get("logs"),
            },
        }

    # --------------------------------------------------------------------------
    # Error Handling
    # --------------------------------------------------------------------------
    except HTTPException:
        raise  # handled by FastAPI

    except Exception as e:
        logger.error(f"[ORCHESTRATOR] Fatal unrecoverable error: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Impact orchestration failed after retries: {str(e)}"
        )
