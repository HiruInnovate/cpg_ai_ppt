"""
This small utility helps our backend agents to talk live with frontend using WebSocket.

Whenever agent is reasoning something (like step, observation, result etc.),
we use this class to push messages in real-time to connected UI session.

💡 Why this class is useful:
Because when we run heavy RCA or Impact workflows, user doesn’t know
what’s happening. With WebSocketEmitter, we can show nice “thinking” steps,
tools being called, and final result — all streamed live to frontend.
"""

import asyncio
from typing import Optional, Any
from backend.services.ws_manager import ws_manager


class WebSocketEmitter:
    """
    This class is like a helper that pushes agent activity logs through websocket.
    Each session gets its own emitter so we can send real-time updates for that user.
    """

    def __init__(self, session_id: Optional[str]):
        """
        Create an emitter instance for a given websocket session.
        If session_id is None, emitter will not send anything.

        Args:
            session_id (str): websocket session id from frontend.
        """
        self.session_id = session_id

    async def emit(self, event: str, message: str, meta: Optional[dict] = None):
        """
        Send a structured event to frontend through WebSocket.

        Args:
            event (str): event name like start, thought, action etc.
            message (str): readable text message.
            meta (dict, optional): extra metadata if needed.
        """
        if not self.session_id:
            return
        payload = {
            "event": event,
            "message": message,
            "meta": meta or {},
        }
        await ws_manager.send_to_session(self.session_id, payload)

    # Convenience wrappers for standard events used by agents
    async def start(self, agent: str):
        """Inform that agent has started reasoning."""
        await self.emit("start", f"{agent} started reasoning", {"agent": agent})

    async def thought(self, text: str):
        """Send intermediate reasoning thought text."""
        await self.emit("thought", text)

    async def action(self, tool: str, tool_input: Any):
        """Notify when an agent tool is called."""
        await self.emit("action", f"Running {tool}", {"tool": tool, "input": str(tool_input)})

    async def observation(self, tool: str, observation: str):
        """Push observation result from tool execution."""
        await self.emit("observation", f"{tool} → {str(observation)[:200]}", {"tool": tool})

    async def result(self, result_json: dict):
        """Send final result JSON of agent."""
        await self.emit("result", "Final Result", {"result": result_json})

    async def error(self, text: str):
        """Send error message if something failed in agent."""
        await self.emit("error", text)

    async def finish(self, agent: str):
        """Notify that agent reasoning process is completed."""
        await self.emit("finish", f"{agent} completed", {"agent": agent})
