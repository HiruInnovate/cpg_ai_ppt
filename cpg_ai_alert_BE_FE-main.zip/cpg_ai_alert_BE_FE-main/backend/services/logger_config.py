"""
This module sets up our custom logger for backend.

Many developers face issue in Windows when log files are in use,
so we made a custom handler which is more safe and don’t crash
the app when rollover (rotation) happens.

It creates both console and file handlers, and ensures that Streamlit
reloads don’t duplicate logs.

💡 Why we wrote this:
Because default logger was giving "Permission denied" issue in Windows
when file was locked. So we wrote a small fix which just copy and truncate
the log safely.

We keep logs in backend/logs/app.log and rotate automatically after 1MB.
"""

import logging
import os
from logging.handlers import RotatingFileHandler
import sys

LOG_DIR = "backend/logs"
os.makedirs(LOG_DIR, exist_ok=True)
LOG_PATH = os.path.join(LOG_DIR, "app.log")


class SafeRotatingFileHandler(RotatingFileHandler):
    """
    Custom RotatingFileHandler which is more Windows friendly.

    When rotation fails due to file being used, it simply copy the log to backup
    and clears the main file, so app continues running.

    We did this because sometimes log viewer tools or antivirus
    locks the file on Windows.
    """

    def doRollover(self):
        """Perform safe rollover without crashing even if file is locked."""
        try:
            super().doRollover()
        except PermissionError:
            import shutil
            backup = f"{self.baseFilename}.1"
            try:
                shutil.copy(self.baseFilename, backup)
                open(self.baseFilename, 'w').close()
                print(f"[LOGGER] Fallback rollover: {backup}")
            except Exception as e:
                print(f"[LOGGER] Rollover failed: {e}")


def get_logger(name: str) -> logging.Logger:
    """
    Returns a configured logger with both file and console handler.

    It also avoids duplicate handlers on Streamlit or FastAPI reload.
    Logs go to both console and rotating file under backend/logs.

    Args:
        name (str): module or class name for logger

    Returns:
        logging.Logger: ready logger instance

    Example:
        >>> from backend.services.logger_config import get_logger
        >>> log = get_logger("test")
        >>> log.info("This is test log")
    """
    logger = logging.getLogger(name)

    # Avoid duplicate handlers (important for Streamlit hot-reload)
    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s")

    # ---- File Handler ----
    file_handler = SafeRotatingFileHandler(
        LOG_PATH,
        maxBytes=1_000_000,  # 1 MB
        backupCount=3,
        delay=True,
        encoding="utf-8"
    )
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)

    # ---- Console Handler ----
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(fmt)
    logger.addHandler(console_handler)

    # ---- Propagation ----
    logger.propagate = False

    logger.info(f"✅ Logger initialized for [{name}] at {LOG_PATH}")
    return logger
