"""
This module handles file upload and data processing in our system.

It helps to save any uploaded file safely, avoid blocking with async write,
and then process it to identify if it is news, shipment, or logistics file etc.

💡 Why we wrote this:
Because many users upload different types of JSON or CSV files, and we needed
a single smart entry point to store and index them. This helps the agents
find data easily later through vector db search or normal storage.

The code is written in a way that a simple developer can understand.
No big frameworks or fancy code, just basic Python, aiofiles and FastAPI.
"""

import os
import uuid
import aiofiles
from fastapi import HTTPException, status, UploadFile
from backend.services.embeddings import index_text
from backend.services.logger_config import get_logger
from backend.services.normalizer import smart_normalize
from backend.services.storage import load_json, overwrite_json

# Initialize logger
logger = get_logger(__name__)

FEED_DIR = "backend/data/feeds"
os.makedirs(FEED_DIR, exist_ok=True)


async def save_upload(uploaded_file: UploadFile) -> str:
    """
    This function saves uploaded file to FEED_DIR.

    It streams file in chunks to avoid memory issue.
    It also handles too-large file by limiting bytes and cleaning incomplete writes.

    Args:
        uploaded_file (UploadFile): file uploaded from frontend

    Returns:
        str: path to saved file

    Example:
        user upload file from UI -> backend saves -> return path.
    """
    os.makedirs(FEED_DIR, exist_ok=True)

    original_name = getattr(uploaded_file, "filename", None) or "unnamed"
    safe_name = os.path.basename(original_name)
    fname = f"{uuid.uuid4().hex}_{safe_name}"
    path = os.path.join(FEED_DIR, fname)

    CHUNK_SIZE = 1024 * 1024  # 1 MB
    MAX_BYTES = 200 * 1024 * 1024  # 200 MB limit

    total = 0
    try:
        async with aiofiles.open(path, "wb") as out_f:
            while True:
                chunk = await uploaded_file.read(CHUNK_SIZE)
                if not chunk:
                    break
                await out_f.write(chunk)
                total += len(chunk)
                if total > MAX_BYTES:
                    await uploaded_file.close()
                    try:
                        await out_f.close()
                    except Exception:
                        pass
                    try:
                        os.remove(path)
                    except Exception:
                        pass
                    raise HTTPException(
                        status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                        detail=f"Uploaded file exceeds maximum allowed size of {MAX_BYTES} bytes."
                    )

        try:
            await uploaded_file.close()
        except Exception:
            pass

        logger.info(f"[INGESTION] Uploaded file saved: {fname} ({total / 1024:.1f} KB)")
        return path

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[INGESTION] Failed to save uploaded file '{original_name}': {e}", exc_info=True)
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception:
            logger.debug("Failed to remove partial file after error: %s", path, exc_info=True)
        raise


def process_file(path):
    """
    This function decide what to do with uploaded file.
    It normalizes, identifies type (shipment/news/social/logistics),
    and then either store or index in chroma DB.

    The decision is made using output of smart_normalize.

    Returns:
        dict: summary result with keys like stored/indexed/type etc
    """
    logger.info(f"[INGESTION] Starting processing for file: {path}")

    try:
        data = smart_normalize(path)
        print(f"[INGESTION] Normalized data from file '{path}': {type(data)}")
        dtype, items = data.get("type"), data.get("items", [])
        logger.info(f"[INGESTION] Detected file type: {dtype} | Total items: {len(items)}")

        if dtype == "shipment_events":
            logger.info(f"[INGESTION] Processing shipment events from file '{path}'")
            existing = load_json("shipments.json")
            logger.debug(f"[INGESTION] Loaded existing shipments: {len(existing)} entries")
            existing.extend(items)
            overwrite_json("shipments.json", existing)
            logger.info(f"[INGESTION] Stored {len(items)} new shipment events (Total now: {len(existing)})")
            return {"stored": len(items), "type": dtype, "namespace": "shipments.json"}

        elif dtype == "news_articles":
            logger.info(f"[INGESTION] Indexing news articles into vector DB (namespace='news_data')")
            count = index_text(items, namespace="news_data")
            logger.info(f"[INGESTION] Indexed {count} news text chunks")
            return {"indexed": count, "type": dtype, "namespace": "news_data"}

        elif dtype == "social_posts":
            logger.info(f"[INGESTION] Indexing social posts into vector DB (namespace='social_data')")
            count = index_text(items, namespace="social_data")
            logger.info(f"[INGESTION] Indexed {count} social media text chunks")
            return {"indexed": count, "type": dtype, "namespace": "social_data"}

        elif dtype == "logistics_performance":
            logger.info(f"[INGESTION] Processing logistics performance data from file '{path}'")
            existing = load_json("logistics_performance.json")
            logger.debug(f"[INGESTION] Loaded existing logistics records: {len(existing)} entries")

            existing.extend(items)
            overwrite_json("logistics_performance.json", existing)
            logger.info(f"[INGESTION] Stored {len(items)} new logistics performance records (Total now: {len(existing)})")

            count = index_text(items, namespace="logistics_data")
            logger.info(f"[INGESTION] Indexed {count} logistics text chunks")
            return {"stored": len(items), "indexed": count, "type": dtype, "namespace": "logistics_data"}

        elif dtype == "text_doc":
            logger.info(f"[INGESTION] Indexing generic text documents (namespace='misc_data')")
            count = index_text(items, namespace="misc_data")
            logger.info(f"[INGESTION] Indexed {count} misc text chunks")
            return {"indexed": count, "type": dtype, "namespace": "misc_data"}

        else:
            logger.warning(f"[INGESTION] Unknown file type for '{path}'. Skipping storage/indexing.")
            return {"type": "unknown", "message": "File not recognized"}

    except Exception as e:
        logger.error(f"[INGESTION] Error while processing file '{path}': {e}", exc_info=True)
        return {"error": str(e), "type": "error"}
