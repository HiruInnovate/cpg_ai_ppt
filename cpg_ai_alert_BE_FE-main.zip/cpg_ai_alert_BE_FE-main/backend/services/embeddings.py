"""
This file is used for handling text embeddings and vector database indexing.

The main work here is to connect with OpenAI or Azure OpenAI model to create embeddings,
store them in Chroma vector db, and then allow retrieval based on namespaces like news, social, misc etc.

Note: This part of the backend help in storing text knowledge in a searchable way, so that later agents
can easily fetch context during reasoning.

 Author's Note:
This is made simple so that any dev can use it for basic RAG setup.
No complex dependency, just plug and use. It will create embeddings for documents
and help to retrieve similar data.
"""

import os
from langchain_chroma import Chroma
from langchain_openai.embeddings import OpenAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from backend.services.logger_config import get_logger
import httpx

client = httpx.Client(verify=False)

# Initialize logger
logger = get_logger(__name__)

# -------------------------------------------------
#  CONFIGURABLE SETTINGS
# -------------------------------------------------
CHROMA_DIR = os.getenv("CHROMA_DIR", "backend/data/vector_db")
USE_AZURE_OPENAI = os.getenv("USE_AZURE_OPENAI", "false").lower() == "true"

# ✅ Ensure vector DB directory exists
os.makedirs(CHROMA_DIR, exist_ok=True)

# ✅ TikToken Cache
TIKTOKEN_CACHE_DIR = os.getenv("TIKTOKEN_CACHE_DIR", "../../tiktoken_cache")
os.environ["TIKTOKEN_CACHE_DIR"] = TIKTOKEN_CACHE_DIR


# -------------------------------------------------
#  EMBEDDING INITIALIZATION FACTORY
# -------------------------------------------------
def create_embedding_model():
    """
    Create the embedding model.
    This function checks if Azure or OpenAI standard API is used and
    initializes the embedding accordingly.

    - In Azure mode, it uses AZURE_OPENAI_ENDPOINT, API_KEY, MODEL.
    - In normal mode, it uses OPENAI_BASE_URL, API_KEY, MODEL.

    Returns:
        OpenAIEmbeddings instance configured with the proper model and API key.
    """
    try:
        if USE_AZURE_OPENAI:
            base_url = os.getenv("AZURE_OPENAI_ENDPOINT", "https://genailab.tcs.in")
            api_key = os.getenv("AZURE_OPENAI_API_KEY", "your_azure_api_key")
            model = os.getenv("AZURE_EMBED_MODEL", "azure/genailab-maas-text-embedding-3-large")
            logger.info(f"[EMBEDDINGS] Using Azure OpenAI embedding model: {model}")
        else:
            base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
            api_key = os.getenv("OPENAI_API_KEY", "your_openai_api_key")
            model = os.getenv("OPENAI_EMBED_MODEL", "text-embedding-3-small")
            logger.info(f"[EMBEDDINGS] Using OpenAI embedding model: {model}")

        return OpenAIEmbeddings(
            base_url=base_url,
            model=model,
            api_key=api_key,
            http_client=client
        )
    except Exception as e:
        logger.error(f"[EMBEDDINGS] Failed to initialize embeddings: {e}")
        raise e


# Global embedding model instance
emb = create_embedding_model()


# -------------------------------------------------
#  TEXT INDEXING AND RETRIEVAL
# -------------------------------------------------
def index_text(docs, namespace="default"):
    """
    Index text documents into chroma database.
    This method breaks text into chunks, create embeddings and store them.

    Args:
        docs (list[dict]): list of dicts having id and text keys.
        namespace (str): collection name.

    Returns:
        int: count of indexed chunks.

    Example:
        >>> index_text([{"id": "news1", "text": "this is some sample"}], "news_data")
    """
    if not docs:
        logger.warning(f"[EMBEDDINGS] No documents provided for namespace '{namespace}'. Skipping indexing.")
        return 0

    logger.info(f"[EMBEDDINGS] Starting indexing for namespace '{namespace}' with {len(docs)} documents.")

    try:
        vectordb = Chroma(
            persist_directory=CHROMA_DIR,
            embedding_function=emb,
            collection_name=namespace
        )

        splitter = RecursiveCharacterTextSplitter(chunk_size=800, chunk_overlap=100)
        all_texts, metadatas, ids = [], [], []

        for d in docs:
            if not isinstance(d, dict) or "text" not in d or "id" not in d:
                logger.warning(f"[EMBEDDINGS] Skipping invalid doc entry: {d}")
                continue

            chunks = splitter.split_text(d["text"])
            for i, ch in enumerate(chunks):
                all_texts.append(ch)
                ids.append(f"{d['id']}_chunk_{i}")
                metadatas.append({"source": d['id']})

        if not all_texts:
            logger.warning(f"[EMBEDDINGS] No text chunks generated for namespace '{namespace}'.")
            return 0

        vectordb.add_texts(texts=all_texts, metadatas=metadatas, ids=ids)
        logger.info(f"[EMBEDDINGS] Successfully indexed {len(all_texts)} text chunks into '{namespace}'.")
        return len(all_texts)

    except Exception as e:
        logger.error(f"[EMBEDDINGS] Error while indexing namespace '{namespace}': {e}", exc_info=True)
        return 0


def get_retrievers():
    """
    Get retrievers for default namespaces (news, social, misc).
    It helps the agents fetch context chunks easily.

    Returns:
        dict: {namespace: retriever}
    """
    retrievers = {}
    try:
        for ns in ["news_data", "social_data", "misc_data"]:
            try:
                vectordb = Chroma(
                    persist_directory=CHROMA_DIR,
                    embedding_function=emb,
                    collection_name=ns
                )
                retrievers[ns] = vectordb.as_retriever(search_kwargs={"k": 5})
                logger.info(f"[RETRIEVER] Initialized retriever for namespace '{ns}'.")
            except Exception as e:
                logger.warning(f"[RETRIEVER] Failed to initialize retriever for '{ns}': {e}")

        logger.info(f"[RETRIEVER] Total retrievers ready: {len(retrievers)}")

    except Exception as e:
        logger.error(f"[RETRIEVER] Error building retrievers: {e}", exc_info=True)

    return retrievers
