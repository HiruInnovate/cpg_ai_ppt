"""
This service is used for handling all image understanding related tasks.

Basically we send a base64 image with some instruction text to OpenAI Vision API
like GPT-4o model and get the result back.
You can ask it to describe, extract data, detect defects, read documents etc.
Very flexible – the behaviour fully depends on `instructions`.

💡 Why we made this:
We needed a single place to handle any kind of visual reasoning use-cases
without writing raw OpenAI API code again and again.
"""

import io
from backend.services.llm_factory import create_vision_model
from backend.services.logger_config import get_logger

logger = get_logger(__name__)


class VisionService:
    """
    VisionService is the helper class that interacts with GPT-4o (or any
    other vision model from OpenAI). It takes base64 image and textual
    instruction and sends to model for analysis.
    """

    def __init__(self, model_name: str = None):
        """
        Initialize Vision client from llm_factory.

        Args:
            model_name (str): optional model name like 'gpt-4o' or 'gpt-4o-mini'
        """
        self.client, self.model = create_vision_model(model_name)

    async def analyze_image(self, image_b64: str, instructions: str) -> dict:
        """
        Analyze the given image using Vision model.

        You can send any base64 image string with some human readable instruction
        like "extract text from invoice" or "describe what object is there".

        Args:
            image_b64: Base64 encoded image data (PNG/JPEG).
            instructions: Text instruction about what to extract.

        Returns:
            dict: Structured JSON with model output or error.
        """
        try:
            logger.info(f"[VISION_SERVICE] Analyzing image with model {self.model}")

            # image_url must be inside object else OpenAI throws error
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "You are a Vision Analysis Agent. "
                            "You analyze and interpret images based on the given instructions."
                        )
                    },
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": instructions},
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/png;base64,{image_b64}"
                                }
                            }
                        ]
                    }
                ],
                max_tokens=800
            )

            text = response.choices[0].message.content
            logger.info("[VISION_SERVICE] Vision analysis completed successfully.")
            return {"status": "success", "output": text, "model": self.model}

        except Exception as e:
            logger.error(f"[VISION_SERVICE] Vision analysis failed: {e}", exc_info=True)
            return {"status": "error", "message": str(e)}
