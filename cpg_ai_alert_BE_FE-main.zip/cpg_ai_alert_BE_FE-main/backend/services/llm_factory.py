"""
This module is like a one-stop factory for creating different LLM model clients.  
It helps to create chat, embedding, and vision models for both OpenAI and Azure setups.  

Why we made this:
Because we wanted to keep LLM creation simple and not spread API keys and endpoints everywhere.  
Just call the right function and it gives you a ready LLM client with all setup done.

💡 It can create:
 - Chat model for conversation or agents
 - Embedding model for vector search
 - Vision model for image understanding

Note: We keep few default env values, so it can work in local laptop also.
"""

import os
import httpx
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from openai import OpenAI
from backend.services.logger_config import get_logger

client = httpx.Client(verify=False)

# -------------------------------------------------
#  LOAD ENV AND LOGGER
# -------------------------------------------------
load_dotenv()
logger = get_logger(__name__)

# -------------------------------------------------
#  FACTORY CONFIG
# -------------------------------------------------
USE_AZURE_OPENAI = os.getenv("USE_AZURE_OPENAI", "false").lower() == "true"
AZURE_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT", "https://genailab.tcs.in")
AZURE_API_KEY = os.getenv("AZURE_OPENAI_API_KEY", "your_azure_api_key")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "your_openai_api_key")

# ✅ Ensure local TikToken cache
TIKTOKEN_CACHE_DIR = os.getenv("TIKTOKEN_CACHE_DIR", "./tiktoken_cache")
os.environ["TIKTOKEN_CACHE_DIR"] = TIKTOKEN_CACHE_DIR


# -------------------------------------------------
#  CHAT MODEL FACTORY
# -------------------------------------------------
def create_chat_model(model: str = 'gpt-4o-mini', temperature: float = 0.2, client: httpx.Client = None,
                      is_agent: bool = False):
    """
    Creates Chat LLM model based on environment.
    It automatically choose Azure or OpenAI mode based on USE_AZURE_OPENAI flag.

    Args:
        model (str): model name like 'gpt-4o-mini'
        temperature (float): controls randomness
        client (httpx.Client): optional, for custom SSL etc.
        is_agent (bool): if True, will add stop tokens for agents

    Returns:
        ChatOpenAI: instance of Langchain Chat model
    """
    if USE_AZURE_OPENAI:
        base_url = AZURE_ENDPOINT
        api_key = AZURE_API_KEY
        model_name = os.getenv("AZURE_CHAT_MODEL", "azure/genailab-maas-gpt-35-turbo")
        logger.info(f"[LLM_FACTORY] Using Azure OpenAI chat model: {model_name}")
    else:
        base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
        api_key = OPENAI_API_KEY
        model_name = os.getenv("OPENAI_CHAT_MODEL", "gpt-4o-mini")
        logger.info(f"[LLM_FACTORY] Using OpenAI chat model: {model_name}")

    if is_agent:
        return ChatOpenAI(
            base_url=base_url,
            model=model_name,
            api_key=api_key,
            temperature=temperature,
            stop=["\nObservation", "Observation"],
            http_client=client or httpx.Client(verify=False)
        )

    return ChatOpenAI(
        base_url=base_url,
        model=model_name,
        api_key=api_key,
        temperature=temperature,
        http_client=client or httpx.Client(verify=False),
        max_tokens=2048
    )


# -------------------------------------------------
#  EMBEDDING MODEL FACTORY
# -------------------------------------------------
def create_embedding_model(model: str = None):
    """
    Creates embedding model for text to vector conversion.
    Same function works for Azure and OpenAI both.  

    Args:
        model (str): optional override model name

    Returns:
        OpenAIEmbeddings: embedding model instance
    """
    if USE_AZURE_OPENAI:
        base_url = AZURE_ENDPOINT
        api_key = AZURE_API_KEY
        model_name = os.getenv("AZURE_EMBED_MODEL", "azure/genailab-maas-text-embedding-3-large")
        logger.info(f"[LLM_FACTORY] Using Azure OpenAI embedding model: {model_name}")
    else:
        base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
        api_key = OPENAI_API_KEY
        model_name = os.getenv("OPENAI_EMBED_MODEL", "text-embedding-3-small")
        logger.info(f"[LLM_FACTORY] Using OpenAI embedding model: {model_name}")

    return OpenAIEmbeddings(
        base_url=base_url,
        model=model_name,
        api_key=api_key,
        http_client=client
    )


# -------------------------------------------------
#  TEST UTILITIES (Optional)
# -------------------------------------------------
def test_llm_factory():
    """
    This function can be used by developer to quick test connection with LLMs.  
    It calls model and send a small hello message.

    Returns:
        bool: True if success, False otherwise
    """
    try:
        chat = create_chat_model()
        logger.info(f"✅ Chat model ready: {chat}")

        response = chat.invoke("Hello! This is a connection test from the CPG AI system.")
        logger.info(f"🤖 LLM Response: {response.content if hasattr(response, 'content') else response}")

        emb = create_embedding_model()
        logger.info(f"✅ Embedding model ready: {emb}")
        return True
    except Exception as e:
        logger.error(f"❌ LLM Factory Test Failed: {e}", exc_info=True)
        return False


# -------------------------------------------------
#  VISION MODEL FACTORY
# -------------------------------------------------
def create_vision_model(model_name: str = None):
    """
    Returns vision-capable OpenAI client.  
    Helps in image understanding cases (like OCR, insights extraction).  

    Args:
        model_name (str): vision model name

    Returns:
        (OpenAI, str): client instance and model name
    """
    model = model_name or os.getenv("OPENAI_VISION_MODEL", "gpt-4o-mini")
    api_key = os.getenv("OPENAI_API_KEY")
    base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")

    logger.info(f"[LLM_FACTORY] Initializing Vision model: {model}")

    client = OpenAI(api_key=api_key, base_url=base_url)
    return client, model
