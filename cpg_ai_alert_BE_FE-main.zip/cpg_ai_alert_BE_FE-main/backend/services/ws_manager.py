"""
This is our small WebSocket connection manager used by backend agents.

Basically it keeps track of who is connected (based on session_id)
and helps to send live data or updates to frontend in real-time.

💡 Why this file is important:
When multiple users or alerts are running their agents at same time,
we need to know which frontend connection belongs to which agent run.
This manager handles that in very simple way using dictionary of sets.
"""

import json
from typing import Dict, Set
from fastapi import WebSocket
from backend.services.logger_config import get_logger

logger = get_logger(__name__)


class WebSocketManager:
    """
    This class manages all websocket connections in system.

    Each session_id (like alert_id or UUID) can have many connections,
    for example if same alert is opened in two browser tabs.
    We can send data to only that session or to everyone.
    """

    def __init__(self):
        """Initialize empty dictionary for tracking connected sockets."""
        self.active_connections: Dict[str, Set[WebSocket]] = {}

    async def connect(self, websocket: WebSocket, session_id: str):
        """
        Accept new websocket connection and register it under session_id.
        """
        await websocket.accept()
        if session_id not in self.active_connections:
            self.active_connections[session_id] = set()
        self.active_connections[session_id].add(websocket)
        logger.info(f"[WS] Connected session={session_id}. Total: {len(self.active_connections[session_id])}")

    def disconnect(self, websocket: WebSocket, session_id: str):
        """
        Remove websocket connection from active list of session.
        """
        if session_id in self.active_connections:
            self.active_connections[session_id].discard(websocket)
            logger.info(f"[WS] Disconnected from session={session_id}")

    async def send_to_session(self, session_id: str, data: dict):
        """
        Send one message to all connected sockets for same session.

        Args:
            session_id (str): Which session to send to
            data (dict): The message data
        """
        if session_id not in self.active_connections:
            return
        message = json.dumps(data, ensure_ascii=False)
        dead = []
        for ws in list(self.active_connections[session_id]):
            try:
                await ws.send_text(message)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(ws, session_id)

    async def broadcast(self, data: dict):
        """
        Send one message to everyone connected (all sessions).
        Useful for system-wide notifications or test broadcast.
        """
        for session_id in list(self.active_connections.keys()):
            await self.send_to_session(session_id, data)


# Global singleton instance used everywhere
ws_manager = WebSocketManager()
