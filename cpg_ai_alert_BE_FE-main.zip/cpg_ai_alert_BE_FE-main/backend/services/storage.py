"""
This file is like our small local database manager.

It helps to read and write JSON data files safely inside backend/data/json_store.
We use it for storing logs, history, metrics and other small data that we don’t
keep in cloud DB.

💡 Why we wrote this:
Because while testing agents and Streamlit, sometimes multiple threads try
to write JSON at same time. So this module ensures everything is thread-safe
and consistent. It also avoids crash if file is missing or corrupted.

Main features:
 - load_json() → safe reading with fallback
 - save_json() → thread-safe write
 - append_json() → add single record easily
 - overwrite_json() → replace full content

Very simple but used everywhere in our backend.
"""

import json
import os
import threading
from backend.services.logger_config import get_logger

# Initialize logger
logger = get_logger(__name__)

# Ensure base directory exists
os.makedirs("backend/data/json_store", exist_ok=True)
_lock = threading.Lock()


def _path(fn):
    """Make full path for given JSON file name in our json_store folder."""
    return os.path.join("backend/data/json_store", fn)


def load_json(fn):
    """
    Safely load JSON file.
    If not exists or broken, it just return [] instead of crashing.

    Args:
        fn (str): filename relative to json_store

    Returns:
        list or dict: loaded data or empty list on failure
    """
    p = _path(fn)
    try:
        if not os.path.exists(p):
            logger.warning(f"[STORAGE] File not found: {p}. Returning empty list.")
            return []

        with open(p, "r", encoding="utf8") as f:
            data = json.load(f)
            logger.debug(f"[STORAGE] Loaded {len(data) if isinstance(data, list) else 'object'} items from {fn}.")
            return data
    except json.JSONDecodeError as e:
        logger.error(f"[STORAGE] JSON decode error in file {fn}: {e}", exc_info=True)
        return []
    except Exception as e:
        logger.error(f"[STORAGE] Error loading file {fn}: {e}", exc_info=True)
        return []


def save_json(fn, data):
    """
    Save JSON file safely with locking.
    If folder not present, it will create automatically.
    """
    p = _path(fn)
    try:
        with _lock:
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, "w", encoding="utf8") as f:
                json.dump(data, f, indent=2, default=str)
            logger.info(f"[STORAGE] Saved {len(data) if isinstance(data, list) else 'object'} items to {fn}.")
    except Exception as e:
        logger.error(f"[STORAGE] Failed to save JSON file {fn}: {e}", exc_info=True)


def append_json(fn, obj):
    """
    Append one record into existing JSON list file.

    If file doesn’t exist, it will create new.
    If file is not a list, it will reset to new list automatically.
    """
    try:
        logger.debug(f"[STORAGE] Appending new record to {fn}.")
        items = load_json(fn)

        if not isinstance(items, list):
            logger.warning(f"[STORAGE] File {fn} does not contain a list. Overwriting with new list.")
            items = []

        items.append(obj)
        save_json(fn, items)
        logger.info(f"[STORAGE] Appended new record to {fn} (total: {len(items)} records).")

    except Exception as e:
        logger.error(f"[STORAGE] Error appending to file {fn}: {e}", exc_info=True)


def overwrite_json(fn, obj):
    """
    Completely replace existing JSON content with new object.

    Usually used when we are refreshing old data, like RAGAS summary file etc.
    """
    try:
        logger.info(f"[STORAGE] Overwriting file {fn} with new data.")
        save_json(fn, obj)
    except Exception as e:
        logger.error(f"[STORAGE] Error overwriting file {fn}: {e}", exc_info=True)
