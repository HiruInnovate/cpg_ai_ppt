# backend/orchestrators/chat_orchestrator.py
import json
import re
from backend.services.logger_config import get_logger
from backend.services.llm_factory import create_chat_model
from backend.agents.rca_agent import run_rca_agent
from backend.agents.impact_analysis_agent import run_impact_agent
from backend.agents.common_tools import get_shipment_details
from backend.agents.rca_agent import load_guardrails

logger = get_logger(__name__)


# -------------------------------------------------------
# STEP 1: Guardrail-based question validation
# -------------------------------------------------------
def is_relevant_to_business(query: str) -> bool:
    guardrails = load_guardrails()
    banned_phrases = guardrails.get("banned_phrases", [])
    irrelevant_signals = ["joke", "weather", "sports", "movie", "news", "game", "song"]

    if any(bp.lower() in query.lower() for bp in banned_phrases):
        logger.warning(f"[GUARDRAIL] Query rejected due to banned phrase: {query}")
        return False

    if any(sig in query.lower() for sig in irrelevant_signals):
        logger.info(f"[GUARDRAIL] Irrelevant query detected: {query}")
        return False

    return True


# -------------------------------------------------------
# STEP 2: Intent classification using LLM
# -------------------------------------------------------
def classify_intent(query: str) -> str:
    """
    Uses lightweight LLM to classify the intent.
    Returns one of ['alert_lookup', 'shipment_details', 'rca_analysis', 'impact_analysis', 'unknown'].
    """
    llm = create_chat_model(temperature=0.0)
    prompt = f"""
    You are an intent classifier for a Supply Chain AI system.
    Classify the user's question into one of the following intents:

    1. alert_lookup — user asks about active alerts or alert summary
    2. shipment_details — user asks about a shipment ID or logistics details
    3. rca_analysis — user asks for causes or analysis of a shipment/alert
    4. impact_analysis — user asks about business or financial impact
    5. unknown — anything else (irrelevant or non-business)

    User Query: "{query}"
    Reply ONLY with one of: alert_lookup, shipment_details, rca_analysis, impact_analysis, unknown
    """

    result = llm.invoke(prompt)
    intent = result.content.strip().lower() if hasattr(result, "content") else str(result).strip().lower()
    if intent not in ["alert_lookup", "shipment_details", "rca_analysis", "impact_analysis"]:
        return "unknown"
    return intent


# -------------------------------------------------------
# STEP 3: Tool/Agent routing logic
# -------------------------------------------------------
def process_chat_query(query: str, user_id: str, context: dict):
    if not is_relevant_to_business(query):
        return {
            "status": "irrelevant",
            "message": "I can only help with business-related questions such as alerts, shipments, RCA, or impact analysis.",
        }

    intent = classify_intent(query)
    logger.info(f"[CHAT_GRAPH] Classified intent: {intent}")

    try:
        # Simple lookups
        if intent == "shipment_details":
            shipment_id = extract_shipment_id(query)
            result = get_shipment_details(shipment_id)
            return {
                "status": "success",
                "type": "shipment_lookup",
                "shipment_id": shipment_id,
                "response": json.loads(result) if isinstance(result, str) and "ERROR" not in result else result,
            }

        elif intent == "alert_lookup":
            from backend.routers.alerts import get_alerts
            alerts = get_alerts()
            return {
                "status": "success",
                "type": "alert_summary",
                "response": alerts,
            }

        # RCA or Impact
        elif intent == "rca_analysis":
            alert = extract_alert_context(context, query)
            result = run_rca_agent(alert)
            return {
                "status": "success",
                "type": "rca_analysis",
                "response": result.get("final_json", {}),
                "trace": result.get("steps", []),
            }

        elif intent == "impact_analysis":
            alert = extract_alert_context(context, query)
            result = run_impact_agent(alert, alert.get("rca") or {}, max_steps=6)
            return {
                "status": "success",
                "type": "impact_analysis",
                "response": result.get("final_json", {}),
                "trace": result.get("steps", []),
            }

        # Fallback
        else:
            return {
                "status": "unknown",
                "message": "I'm not sure how to handle that. Try asking about alerts, shipments, or RCA analysis.",
            }

    except Exception as e:
        logger.error(f"[CHAT_GRAPH] Error in routing: {e}", exc_info=True)
        return {"status": "error", "message": str(e)}


# -------------------------------------------------------
# Helper extractors
# -------------------------------------------------------
def extract_shipment_id(query: str) -> str:
    """Extracts potential shipment IDs like SHP1234 from query text."""
    match = re.search(r"(SHP\d+)", query, re.IGNORECASE)
    return match.group(1) if match else "UNKNOWN"


def extract_alert_context(context: dict, query: str) -> dict:
    """Build alert context for RCA/Impact agents."""
    if "alert" in context:
        return context["alert"]
    match = re.search(r"(ALRT_\d+|SHP\d+)", query, re.IGNORECASE)
    alert_id = match.group(1) if match else "TEMP_ALERT"
    return {"alert_id": alert_id, "summary": query}
