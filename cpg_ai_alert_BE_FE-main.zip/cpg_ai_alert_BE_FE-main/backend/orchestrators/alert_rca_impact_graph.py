from typing import TypedDict, Optional, List, Any
from langgraph.constants import END
from langgraph.graph import StateGraph

from backend.agents.impact_analysis_agent import run_impact_agent
from backend.agents.rca_agent import run_rca_agent
from backend.services.logger_config import get_logger

logger = get_logger(__name__)


class FlowState(TypedDict):
    alert: dict
    rca: Optional[dict]
    impact: Optional[dict]
    recommendations: Optional[dict]
    comm_result: Optional[dict]
    traces: List[dict]
    logs: List[str]


# ---------------------------------------------------------------------------
# RCA Node
# ---------------------------------------------------------------------------
def node_rca(state: FlowState) -> FlowState:
    """Run the RCA agent and store its trace + logs in the state."""
    logger.info("[GRAPH] Executing RCA agent node...")

    try:
        res = run_rca_agent(state["alert"], max_steps=6)

        # --- 🧩 Check for structured error ---
        if isinstance(res, dict) and res.get("error"):
            msg = res.get("message", "RCA Agent returned structured error")
            logger.error(f"[GRAPH] RCA Agent failed: {msg}")
            return {
                **state,
                "error": True,
                "message": msg,
                "rca": {},
                "traces": state.get("traces", []),
                "logs": state.get("logs", []) + [f"RCA Error: {msg}"]
            }

        # --- Append traces and logs ---
        traces = state.get("traces", [])
        logs = state.get("logs", [])

        traces.append({
            "agent": "RCA_Agent",
            "steps": res.get("steps", [])
        })
        logs.append(f"--- RCA Agent Logs ---\n{res.get('logs', '')}")

        logger.info("[GRAPH] RCA agent node completed successfully.")
        return {
            **state,
            "rca": res.get("final_json") or {},
            "traces": traces,
            "logs": logs
        }

    except Exception as e:
        msg = f"Exception in RCA agent node: {str(e)}"
        logger.error(f"[GRAPH] {msg}", exc_info=True)
        return {
            **state,
            "error": True,
            "message": msg,
            "rca": {},
            "traces": state.get("traces", []),
            "logs": state.get("logs", []) + [f"RCA Exception: {msg}"]
        }


# ---------------------------------------------------------------------------
# IMPACT Node
# ---------------------------------------------------------------------------
def node_impact(state: FlowState) -> FlowState:
    """Run the Impact Assessment agent and propagate trace and logs."""
    logger.info("[GRAPH] Executing Impact agent node...")

    # If RCA failed, stop further processing
    if state.get("error"):
        msg = f"Skipping Impact Agent — previous RCA failed: {state.get('message')}"
        logger.warning(f"[GRAPH] {msg}")
        raise Exception

    try:
        res = run_impact_agent(state["alert"], state.get("rca") or {}, max_steps=8)

        # --- 🧩 Check for structured error ---
        if isinstance(res, dict) and res.get("error"):
            msg = res.get("message", "Impact Agent returned structured error")
            logger.error(f"[GRAPH] Impact Agent failed: {msg}")
            raise Exception

        # --- Append traces and logs ---
        traces = state.get("traces", [])
        logs = state.get("logs", [])

        traces.append({
            "agent": "Impact_Agent",
            "steps": res.get("steps", [])
        })
        logs.append(f"--- Impact Agent Logs ---\n{res.get('logs', '')}")

        logger.info("[GRAPH] Impact agent node completed successfully.")
        return {
            **state,
            "impact": res.get("final_json") or {},
            "traces": traces,
            "logs": logs
        }

    except Exception as e:
        msg = f"Exception in Impact agent node: {str(e)}"
        logger.error(f"[GRAPH] {msg}", exc_info=True)
        raise e


# ---------------------------------------------------------------------------
# Flow Builder
# ---------------------------------------------------------------------------
def build_flow():
    """Build the multi-agent orchestration pipeline with error propagation."""
    g = StateGraph(FlowState)

    g.add_node("rca", node_rca)
    g.add_node("impact", node_impact)

    g.set_entry_point("rca")
    g.add_edge("rca", "impact")
    g.add_edge("impact", END)

    logger.info("[GRAPH] Flow graph built successfully.")
    return g.compile()
