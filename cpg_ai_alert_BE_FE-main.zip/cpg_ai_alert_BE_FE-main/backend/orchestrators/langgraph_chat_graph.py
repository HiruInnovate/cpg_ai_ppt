import json
import os
import re
from datetime import datetime
from typing import TypedDict, Optional, Any, List

from langgraph.constants import END
from langgraph.graph import StateGraph

from backend.agents.impact_analysis_agent import run_impact_agent
from backend.agents.rca_agent import run_rca_agent, load_guardrails
from backend.agents.common_tools import (
    get_shipment_details,
    get_logistics_performance,
    search_external_context,
)
from backend.orchestrators.alert_rca_impact_graph import build_flow
from backend.services.llm_factory import create_chat_model
from backend.services.logger_config import get_logger

logger = get_logger(__name__)

CHAT_HISTORY_PATH = "backend/data/json_store/chat_history.json"


# ---------------------------------------------------------------------------
# Chat State Definition
# ---------------------------------------------------------------------------
class ChatState(TypedDict, total=False):
    user_id: str
    history: List[dict]
    last_user_message: str
    decision: dict
    tool_output: Any
    final_response: str
    guardrail_passed: bool
    error: Optional[str]
    message: Optional[str]


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------
def load_chat_history(user_id: str) -> List[dict]:
    try:
        if os.path.exists(CHAT_HISTORY_PATH):
            with open(CHAT_HISTORY_PATH, "r", encoding="utf8") as f:
                data = json.load(f)
            return data.get(user_id, [])
    except Exception as e:
        logger.error(f"[CHAT_HISTORY] load error: {e}", exc_info=True)
    return []


def save_chat_history(user_id: str, history: List[dict]):
    try:
        os.makedirs(os.path.dirname(CHAT_HISTORY_PATH), exist_ok=True)
        data = {}
        if os.path.exists(CHAT_HISTORY_PATH):
            with open(CHAT_HISTORY_PATH, "r", encoding="utf8") as f:
                data = json.load(f)
        data[user_id] = history
        with open(CHAT_HISTORY_PATH, "w", encoding="utf8") as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        logger.error(f"[CHAT_HISTORY] save error: {e}", exc_info=True)


def passes_guardrails(query: str) -> bool:
    guard = load_guardrails()
    banned = guard.get("banned_phrases", [])
    irrelevant = ["song", "movie", "joke", "recipe", "sports"]

    if any(bp.lower() in query.lower() for bp in banned):
        logger.warning(f"[GUARDRAIL] Query contains banned phrase: {query}")
        return False
    if any(sig in query.lower() for sig in irrelevant):
        logger.info(f"[GUARDRAIL] Query appears irrelevant: {query}")
        return False
    return True


def extract_shipment_id(query: str) -> Optional[str]:
    match = re.search(r"(SHP\d+)", query, re.IGNORECASE)
    return match.group(1) if match else None


def extract_carrier_name(query: str) -> Optional[str]:
    match = re.search(r"\b(DTDC|FedEx|BlueDart|DHL|EcomExpress)\b", query, re.IGNORECASE)
    return match.group(1) if match else None


# ---------------------------------------------------------------------------
# Format LLM Output to Human Text
# ---------------------------------------------------------------------------
def format_to_human(action: str, data: Any, user_query: str = "") -> str:
    try:
        if isinstance(data, str):
            try:
                data = json.loads(data)
            except Exception:
                return data

        if action == "shipment_details":
            rec = data[0] if isinstance(data, list) else data
            context_summary = (
                f"Shipment ID: {rec.get('shipment_id', 'unknown')}\n"
                f"Location: {rec.get('location', 'unknown')}\n"
                f"Carrier: {rec.get('carrier', 'N/A')}\n"
                f"Remarks: {rec.get('remarks', 'No remarks')}"
            )

        elif action == "rca_analysis":
            causes = data.get("causes", [])
            cause_text = "; ".join(
                [f"{c.get('label')}: {c.get('explanation')}" for c in causes]
            )
            context_summary = (
                f"RCA Summary: {data.get('summary', '')}\n"
                f"Causes: {cause_text}\n"
                f"Recommendations: "
                f"{', '.join([r.get('action') for r in data.get('recommendations', [])])}"
            )

        elif action == "impact_analysis":
            imp = data.get("impact_summary", "")
            total = data.get("total", {}).get("overall", 0)
            assumptions = data.get("assumptions", [])
            context_summary = (
                f"Impact Summary: {imp}\n"
                f"Total Financial Impact: ₹{total:,}\n"
                f"Assumptions: {', '.join(assumptions)}"
            )

        elif action == "carrier_performance":
            context_summary = f"Carrier performance details:\n{json.dumps(data, indent=2)}"

        elif action == "external_context":
            context_summary = f"External data snippets:\n{data}"

        else:
            context_summary = json.dumps(data, indent=2)

        llm = create_chat_model(temperature=0.1)
        system_prompt = (
            "You are an assistant that summarizes supply chain insights conversationally. "
            "Rewrite the provided structured data into a short, natural chat reply "
            "that clearly answers the user's question while maintaining accuracy."
        )
        user_prompt = f"""
User Query:
{user_query or '(no user query provided)'}

Action Type: {action}
Structured Data:
{context_summary}
        """
        llm_response = llm.invoke(
            [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ]
        )

        if hasattr(llm_response, "content"):
            return llm_response.content.strip()
        elif isinstance(llm_response, str):
            return llm_response.strip()
        else:
            return json.dumps(llm_response, indent=2)

    except Exception as e:
        logger.error(f"[FORMAT] Failed formatting {action}: {e}", exc_info=True)
        return "I encountered an issue formatting this response, but the raw data is available."


# ---------------------------------------------------------------------------
# Graph Nodes
# ---------------------------------------------------------------------------
def node_receive(state: ChatState) -> ChatState:
    msg = state["last_user_message"]
    ok = passes_guardrails(msg)
    state["guardrail_passed"] = ok
    if not ok:
        state["final_response"] = "Sorry, I cannot help with that request."
        state["decision"] = {"action": "rejected", "arguments": {}, "rationale": "guardrail triggered"}
        return state
    return state


def node_decide(state: ChatState) -> ChatState:
    history = state.get("history", [])
    recent = "\n".join(f"{m['role']}: {m['message']}" for m in history[-5:])
    prompt = f"""
You are the routing assistant for a supply-chain inquiry system.  
Available actions: shipment_details, carrier_performance, rca_analysis, impact_analysis, external_context, small_talk.
impact_analysis - needs input arguments alert id

Recent chat: 
{recent}

User asks: "{state['last_user_message']}"

Respond in pure JSON only:
{{"action": "<action>", "arguments": {{...}}, "rationale": "<why chosen>"}}
    """
    llm = create_chat_model(temperature=0.2)
    resp = llm.invoke(prompt)
    try:
        parsed = json.loads(getattr(resp, "content", str(resp)))
    except Exception as e:
        logger.error(f"[CHAT_GRAPH] Decision parsing failed: {e}", exc_info=True)
        parsed = {"action": "small_talk", "arguments": {}, "rationale": "parse error"}
    state["decision"] = parsed
    return state


def node_call_tool(state: ChatState) -> ChatState:
    dec = state.get("decision", {})
    action = dec.get("action")
    args = dec.get("arguments", {})

    try:
        if action == "shipment_details":
            sid = args.get("shipment_id") or extract_shipment_id(state["last_user_message"])
            out = get_shipment_details(sid)

        elif action == "carrier_performance":
            cname = args.get("carrier_name") or args.get("carrier") or extract_carrier_name(state["last_user_message"])
            out = get_logistics_performance(cname)

        elif action == "rca_analysis":
            alert = args.get("alert") or {"alert_id": args.get("alert_id", "UNKNOWN")}
            out = run_rca_agent(alert)

            if isinstance(out, dict) and out.get("error"):
                msg = out.get("message", "RCA Agent failed.")
                logger.error(f"[CHAT_GRAPH] RCA Agent error: {msg}")
                raise Exception(msg)

            out = out.get("final_json", {})

        elif action == "impact_analysis":
            alert = args.get("alert") or {"alert_id": args.get("alert_id", "UNKNOWN")}
            flow = build_flow()

            initial_state = {
                "alert": alert,
                "rca": None,
                "impact": None,
                "recommendations": None,
                "comm_result": None,
                "traces": [],
                "logs": [],
            }

            out = flow.invoke(initial_state)

            if isinstance(out, dict) and out.get("error"):
                msg = out.get("message", "Impact Agent failed.")
                logger.error(f"[CHAT_GRAPH] Impact Agent error: {msg}")
                raise Exception(msg)

        elif action == "external_context":
            out = search_external_context(state["last_user_message"])

        else:
            out = {"message": "No action taken."}

        state["tool_output"] = out
        return state

    except Exception as e:
        msg = f"Error executing action '{action}': {str(e)}"
        logger.error(f"[CHAT_GRAPH] {msg}", exc_info=True)
        state["error"] = msg
        state["tool_output"] = {"error": True, "message": msg}
        return state


def node_format_response(state: ChatState) -> ChatState:
    dec = state.get("decision", {})
    action = dec.get("action")
    raw = state.get("tool_output")
    formatted = format_to_human(action, raw, state.get("last_user_message", ""))
    state["final_response"] = formatted
    return state


def node_end(state: ChatState) -> ChatState:
    user_id = state.get("user_id")
    if user_id:
        hist = state.get("history", [])
        hist.append(
            {"role": "assistant", "message": state.get("final_response", ""), "time": datetime.now().isoformat()})
        save_chat_history(user_id, hist)
    return state


# ---------------------------------------------------------------------------
# Flow Builder
# ---------------------------------------------------------------------------
def build_chat_flow():
    g = StateGraph(ChatState)

    g.add_node("receive", node_receive)
    g.add_node("decide", node_decide)
    g.add_node("call_tool", node_call_tool)
    g.add_node("format", node_format_response)
    g.add_node("end", node_end)

    g.set_entry_point("receive")

    def route_after_receive(state: ChatState) -> str:
        return "decide" if state.get("guardrail_passed", False) else "format"

    g.add_conditional_edges("receive", route_after_receive, {"decide": "decide", "format": "format"})
    g.add_edge("decide", "call_tool")
    g.add_edge("call_tool", "format")
    g.add_edge("format", "end")
    g.add_edge("end", END)

    logger.info("[CHAT_GRAPH] Chat flow built successfully.")
    return g.compile()
