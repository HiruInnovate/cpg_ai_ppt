from pydantic import BaseModel, Field
from typing import Optional
import os
from dotenv import load_dotenv

load_dotenv()

class Settings(BaseModel):
    # Neo4j
    neo4j_uri: str = Field(default_factory=lambda: os.getenv("NEO4J_URI", "bolt://localhost:7687"))
    neo4j_user: str = Field(default_factory=lambda: os.getenv("NEO4J_USER", "neo4j"))
    neo4j_password: str = Field(default_factory=lambda: os.getenv("NEO4J_PASSWORD", "password"))
    neo4j_database: str = Field(default_factory=lambda: os.getenv("NEO4J_DATABASE", "neo4j"))

    # OpenAI
    openai_api_key: Optional[str] = Field(default_factory=lambda: os.getenv("OPENAI_API_KEY"))
    use_azure_openai: bool = Field(default_factory=lambda: os.getenv("USE_AZURE_OPENAI", "false").lower() == "true")
    azure_openai_api_key: Optional[str] = Field(default_factory=lambda: os.getenv("AZURE_OPENAI_API_KEY"))
    azure_openai_endpoint: Optional[str] = Field(default_factory=lambda: os.getenv("AZURE_OPENAI_ENDPOINT"))
    azure_openai_api_version: str = Field(default_factory=lambda: os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21"))
    azure_openai_deployment: str = Field(default_factory=lambda: os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o-mini"))

    # Graph extraction defaults
    graph_extraction_model: str = Field(default_factory=lambda: os.getenv("GRAPH_EXTRACTION_MODEL", "gpt-4o-mini"))
    graph_extraction_temperature: float = Field(default_factory=lambda: float(os.getenv("GRAPH_EXTRACTION_TEMPERATURE", "0.0")))
    graph_min_confidence: float = Field(default_factory=lambda: float(os.getenv("GRAPH_MIN_CONFIDENCE", "0.7")))

    # Chunking
    chunk_size: int = Field(default_factory=lambda: int(os.getenv("CHUNK_SIZE", "800")))
    chunk_overlap: int = Field(default_factory=lambda: int(os.getenv("CHUNK_OVERLAP", "150")))

settings = Settings()
