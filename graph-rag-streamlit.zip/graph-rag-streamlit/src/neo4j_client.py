from neo4j import GraphDatabase
from .config import settings

class Neo4jClient:
    def __init__(self, uri=None, user=None, password=None, database=None):
        self.driver = GraphDatabase.driver(uri or settings.neo4j_uri, auth=(user or settings.neo4j_user, password or settings.neo4j_password))
        self.database = database or settings.neo4j_database

    def close(self):
        self.driver.close()

    def execute_query(self, query, parameters=None):
        with self.driver.session(database=self.database) as session:
            result = session.run(query, parameters or {})
            return [dict(r) for r in result]

    def execute_write(self, query, parameters=None):
        with self.driver.session(database=self.database) as session:
            session.run(query, parameters or {})

def setup_neo4j_indexes(client: "Neo4jClient"):
    client.execute_write("""        CREATE CONSTRAINT entity_canonical_name IF NOT EXISTS
        FOR (e:Entity) REQUIRE e.name IS UNIQUE
    """)
    client.execute_write("""        CREATE INDEX entity_type_idx IF NOT EXISTS
        FOR (e:Entity) ON (e.type)
    """)
    client.execute_write("""        CREATE INDEX entity_confidence_idx IF NOT EXISTS
        FOR (e:Entity) ON (e.confidence)
    """)
    client.execute_write("""        CREATE CONSTRAINT chunk_id IF NOT EXISTS
        FOR (c:Chunk) REQUIRE c.id IS UNIQUE
    """)
