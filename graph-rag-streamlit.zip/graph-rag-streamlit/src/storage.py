import json, os
from typing import Dict, List

STORAGE_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "storage", "chunks.json")

def _ensure_file():
    os.makedirs(os.path.dirname(STORAGE_PATH), exist_ok=True)
    if not os.path.exists(STORAGE_PATH):
        with open(STORAGE_PATH, "w", encoding="utf-8") as f:
            json.dump({}, f)

def save_chunks(doc_id: str, chunks: List[str]):
    _ensure_file()
    with open(STORAGE_PATH, "r", encoding="utf-8") as f:
        db = json.load(f)
    for i, text in enumerate(chunks):
        chunk_id = f"{doc_id}:{i}"
        db[chunk_id] = text
    with open(STORAGE_PATH, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=2)

def get_chunk_texts(chunk_ids: List[str]) -> Dict[str, str]:
    _ensure_file()
    with open(STORAGE_PATH, "r", encoding="utf-8") as f:
        db = json.load(f)
    return {cid: db.get(cid, "") for cid in chunk_ids}
