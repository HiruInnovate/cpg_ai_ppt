import json, re
from typing import List, Tuple, Dict, Any
from .config import settings
from .models import Entity, Relation

# Optional: we support either OpenAI or Azure OpenAI via the 'openai' package v1+
try:
    from openai import OpenAI, AzureOpenAI
except Exception:
    OpenAI = None
    AzureOpenAI = None

GRAPH_EXTRACTION_SYSTEM_PROMPT = """You are a knowledge graph builder. Extract entities and relationships from text.

## Instructions
1. Identify key entities (people, organizations, concepts, etc.)
2. Normalize entity names (e.g., "AI" and "Artificial Intelligence" → "Artificial_Intelligence")
3. Extract clear relationships between entities
4. Assign confidence scores (0.0-1.0) based on evidence clarity
5. Return results in JSON format

## Output Format
{
  "entities": [
    {
      "name": "Entity_Name",
      "type": "Person/Organization/Concept/etc",
      "confidence": 0.9
    }
  ],
  "relations": [
    {
      "source": "Entity_A",
      "target": "Entity_B",
      "relation_type": "RELATED_TO",
      "confidence": 0.85
    }
  ]
}

Be precise and conservative."""

GRAPH_EXTRACTION_USER_PROMPT = """Extract entities and relationships from the following text.

**Text:**
{text}

Return only valid JSON."""

class LLMClient:
    def __init__(self):
        if settings.use_azure_openai:
            if AzureOpenAI is None:
                raise RuntimeError("openai package not available")
            self.client = AzureOpenAI(
                api_key=settings.azure_openai_api_key,
                api_version=settings.azure_openai_api_version,
                azure_endpoint=settings.azure_openai_endpoint
            )
            self.model = settings.azure_openai_deployment
            self.is_azure = True
        else:
            if OpenAI is None:
                raise RuntimeError("openai package not available")
            self.client = OpenAI(api_key=settings.openai_api_key)
            self.model = settings.graph_extraction_model
            self.is_azure = False

    def chat(self, messages, temperature=0.0):
        if self.is_azure:
            return self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature
            )
        else:
            return self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature
            )

class GraphEntityExtractor:
    def __init__(self, llm: LLMClient, model: str = None, temperature: float = 0.0):
        self.llm = llm
        self.model = model or settings.graph_extraction_model
        self.temperature = temperature

    def extract(self, text: str, chunk_id: str) -> Tuple[List[Entity], List[Relation], Dict[str, int]]:
        user_prompt = GRAPH_EXTRACTION_USER_PROMPT.format(text=text)
        messages = [
            {"role": "system", "content": GRAPH_EXTRACTION_SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ]
        response = self.llm.chat(messages, temperature=self.temperature)
        # openai v1 returns usage like response.usage.total_tokens sometimes; guard for None
        usage = getattr(response, "usage", None)
        token_usage = {
            "prompt_tokens": getattr(usage, "prompt_tokens", 0) if usage else 0,
            "completion_tokens": getattr(usage, "completion_tokens", 0) if usage else 0,
            "total_tokens": getattr(usage, "total_tokens", 0) if usage else 0,
        }
        response_text = response.choices[0].message.content
        entities, relations = self._parse_response(response_text, chunk_id)
        return entities, relations, token_usage

    def _parse_response(self, response_text: str, chunk_id: str):
        json_match = re.search(r"```(?:json)?\s*(.*?)```", response_text, re.DOTALL)
        json_str = json_match.group(1).strip() if json_match else response_text
        try:
            data = json.loads(json_str)
        except Exception:
            return [], []
        entities = []
        for ent in data.get("entities", []):
            entities.append(Entity(
                name=ent.get("name", ""),
                type=ent.get("type", "Concept"),
                confidence=float(ent.get("confidence", 0.5)),
                chunk_id=chunk_id
            ))
        relations = []
        for rel in data.get("relations", []):
            relations.append(Relation(
                source=rel.get("source", ""),
                target=rel.get("target", ""),
                relation_type=rel.get("relation_type", "RELATED_TO"),
                confidence=float(rel.get("confidence", 0.5))
            ))
        return entities, relations
