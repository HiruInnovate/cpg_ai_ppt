from pydantic import BaseModel
from typing import Optional

class Entity(BaseModel):
    name: str
    type: str
    confidence: float
    chunk_id: Optional[str] = None

class Relation(BaseModel):
    source: str
    target: str
    relation_type: str
    confidence: float
