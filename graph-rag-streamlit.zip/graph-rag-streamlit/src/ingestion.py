from typing import Dict, Any, List
from .extractor import GraphEntityExtractor, LLMClient
from .graph_store import GraphStore
from .storage import save_chunks
from .config import settings

def chunk_text(text: str, chunk_size: int = None, chunk_overlap: int = None) -> List[str]:
    size = chunk_size or settings.chunk_size
    overlap = chunk_overlap or settings.chunk_overlap
    chunks = []
    start = 0
    while start < len(text):
        end = start + size
        chunks.append(text[start:end])
        start += max(1, size - overlap)
    return chunks

def ingest_document(
    doc_id: str,
    text: str,
    graph_store: GraphStore,
    min_confidence: float = None,
    chunk_size: int = None,
    chunk_overlap: int = None
) -> Dict[str, Any]:
    min_conf = min_confidence if min_confidence is not None else settings.graph_min_confidence
    chunks = chunk_text(text, chunk_size, chunk_overlap)
    save_chunks(doc_id, chunks)

    llm = LLMClient()
    extractor = GraphEntityExtractor(llm, temperature=settings.graph_extraction_temperature)

    all_entities = []
    all_relations = []
    total_tokens = {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}

    for i, ct in enumerate(chunks):
        chunk_id = f"{doc_id}:{i}"
        entities, relations, tokens = extractor.extract(ct, chunk_id)
        for k in total_tokens:
            total_tokens[k] = total_tokens.get(k, 0) + tokens.get(k, 0)
        entities = [e for e in entities if e.confidence >= min_conf]
        relations = [r for r in relations if r.confidence >= min_conf]
        all_entities.extend(entities)
        all_relations.extend(relations)

    for e in all_entities:
        graph_store.upsert_entity(e, doc_id)

    for r in all_relations:
        graph_store.upsert_relation(r)

    return {
        "doc_id": doc_id,
        "chunks_processed": len(chunks),
        "entities_extracted": len(all_entities),
        "relations_extracted": len(all_relations),
        "token_usage": total_tokens
    }
