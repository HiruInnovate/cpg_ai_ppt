from .models import Entity, Relation
from .neo4j_client import Neo4jClient

class GraphStore:
    def __init__(self, neo4j_client: Neo4jClient):
        self.client = neo4j_client

    def upsert_entity(self, entity: Entity, doc_id: str):
        query = """        MERGE (e:Entity {name: $name})
        ON CREATE SET
            e.type = $type,
            e.confidence = $confidence,
            e.created_at = datetime()
        ON MATCH SET
            e.confidence = CASE WHEN $confidence > e.confidence THEN $confidence ELSE e.confidence END,
            e.updated_at = datetime()
        WITH e
        MERGE (c:Chunk {id: $chunk_id})
        MERGE (e)-[:MENTIONED_IN]->(c)
        WITH e, c
        MERGE (d:Document {id: $doc_id})
        MERGE (c)-[:PART_OF]->(d)
        RETURN e.name as name
        """
        params = {
            "name": entity.name,
            "type": entity.type,
            "confidence": entity.confidence,
            "chunk_id": entity.chunk_id,
            "doc_id": doc_id
        }
        self.client.execute_write(query, params)

    def upsert_relation(self, relation: Relation):
        rel_type = relation.relation_type.upper().replace(" ", "_")
        query = f"""        MATCH (source:Entity {{name: $source}})
        MATCH (target:Entity {{name: $target}})
        MERGE (source)-[r:{rel_type}]->(target)
        ON CREATE SET
            r.confidence = $confidence,
            r.created_at = datetime()
        ON MATCH SET
            r.confidence = CASE WHEN $confidence > r.confidence THEN $confidence ELSE r.confidence END,
            r.updated_at = datetime()
        RETURN type(r) as relation_type
        """
        params = {"source": relation.source, "target": relation.target, "confidence": relation.confidence}
        try:
            self.client.execute_write(query, params)
        except Exception as e:
            print(f"Relation upsert failed {relation.source}->{relation.target}: {e}")
