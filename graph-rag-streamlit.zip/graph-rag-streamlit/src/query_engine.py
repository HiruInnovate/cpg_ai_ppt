import json
from typing import List, Dict, Any
from .config import settings
from .neo4j_client import Neo4jClient
from .storage import get_chunk_texts
from .extractor import LLMClient

QUERY_UNDERSTANDING_PROMPT = """Extract key entities from this query that might exist in a knowledge graph.

Query: {query}

Return JSON with entities:
{{
  "entities": ["Entity_Name_1", "Entity_Name_2"]
}}"""

ANSWER_PROMPT = """Answer this question using only the provided information.

Question: {query}

Retrieved Information:
{chunks}

Entities mentioned: {entities}

Answer:"""

def understand_query(query: str, llm: LLMClient, model: str = None) -> List[str]:
    prompt = QUERY_UNDERSTANDING_PROMPT.format(query=query)
    response = llm.chat([{"role": "user", "content": prompt}], temperature=0.0)
    text = response.choices[0].message.content
    try:
        data = json.loads(text)
        return data.get("entities", [])
    except Exception:
        return []

def graph_search(entity_names: List[str], neo4j: Neo4jClient, max_hops: int = 2) -> List[Dict[str, Any]]:
    if not entity_names:
        return []
    query = f"""    MATCH (start:Entity)
    WHERE start.name IN $entity_names
    MATCH path = (start)-[*0..{max_hops}]-(related:Entity)
    MATCH (related)-[:MENTIONED_IN]->(chunk:Chunk)
    RETURN DISTINCT
        chunk.id as chunk_id,
        collect(DISTINCT related.name) as entities,
        [rel IN relationships(path) | type(rel)] as path
    LIMIT 50
    """
    return neo4j.execute_query(query, {"entity_names": entity_names})

def generate_answer(query: str, chunk_results: List[Dict[str, Any]], llm: LLMClient) -> str:
    chunk_ids = [r["chunk_id"] for r in chunk_results]
    chunk_texts = get_chunk_texts(chunk_ids)
    chunks_text = []
    all_entities = set()
    for r in chunk_results:
        cid = r["chunk_id"]
        text = chunk_texts.get(cid, "")
        chunks_text.append(f"[{cid}] {text}")
        for e in r.get("entities", []):
            all_entities.add(e)

    prompt = ANSWER_PROMPT.format(
        query=query,
        chunks="\n\n".join(chunks_text),
        entities=", ".join(sorted(all_entities))
    )
    response = llm.chat([{"role": "user", "content": prompt}], temperature=0.3)
    return response.choices[0].message.content
