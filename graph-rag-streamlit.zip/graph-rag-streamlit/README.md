# Graph RAG — Streamlit App

A minimal, production-ready implementation of **Graph RAG** (Retrieval-Augmented Generation with Knowledge Graphs) using Neo4j + OpenAI, with a Streamlit UI for ingestion and querying.

> This codebase is generated from the "Graph RAG - Reusable Implementation Guide" provided by the user.

## Features
- Upload & ingest documents (TXT/MD) → chunk → LLM entity/relation extraction → store in Neo4j.
- Query with multi-hop graph traversal and answer synthesis.
- Works with **OpenAI** or **Azure OpenAI** (toggle via `.env`).

## Quickstart

1. Create and populate your `.env` from `.env.example`.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Ensure Neo4j is running and accessible per your `.env`.
4. Launch the app:
   ```bash
   streamlit run streamlit_app.py
   ```

## Notes
- For PDFs or other formats, convert to text before uploading (out of scope for this minimal sample).
- The app stores chunk texts in `storage/chunks.json` for retrieval.

