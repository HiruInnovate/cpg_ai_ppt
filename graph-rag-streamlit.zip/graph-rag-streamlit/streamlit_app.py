import streamlit as st
from src.config import settings
from src.neo4j_client import Neo4jClient, setup_neo4j_indexes
from src.graph_store import GraphStore
from src.ingestion import ingest_document
from src.query_engine import understand_query, graph_search, generate_answer
from src.extractor import LLMClient
import uuid

st.set_page_config(page_title="Graph RAG — Streamlit", page_icon="🕸️", layout="wide")

st.title("🕸️ Graph RAG — Streamlit")

with st.sidebar:
    st.header("Configuration")
    st.caption("Update `.env` or override below:")
    neo4j_uri = st.text_input("Neo4j URI", value=settings.neo4j_uri)
    neo4j_user = st.text_input("Neo4j User", value=settings.neo4j_user)
    neo4j_password = st.text_input("Neo4j Password", value=settings.neo4j_password, type="password")
    neo4j_db = st.text_input("Neo4j Database", value=settings.neo4j_database)

    st.divider()
    use_azure = st.toggle("Use Azure OpenAI", value=settings.use_azure_openai)
    if use_azure:
        st.text_input("Azure Endpoint", value=settings.azure_openai_endpoint, key="azure_ep")
        st.text_input("Azure API Version", value=settings.azure_openai_api_version, key="azure_ver")
        st.text_input("Azure Deployment", value=settings.azure_openai_deployment, key="azure_dep")
    else:
        st.text_input("OpenAI Model", value=settings.graph_extraction_model, key="openai_model")

tab_ingest, tab_query = st.tabs(["📥 Ingest", "❓ Ask"])

with tab_ingest:
    st.subheader("Upload a document")
    up = st.file_uploader("Upload .txt or .md", type=["txt", "md"])
    col1, col2, col3 = st.columns(3)
    with col1:
        doc_id = st.text_input("Document ID", value=f"doc-{uuid.uuid4().hex[:8]}")
    with col2:
        chunk_size = st.number_input("Chunk size", value=settings.chunk_size, min_value=200, max_value=5000, step=50)
    with col3:
        overlap = st.number_input("Chunk overlap", value=settings.chunk_overlap, min_value=0, max_value=1000, step=10)
    min_conf = st.slider("Min confidence", 0.0, 1.0, value=float(settings.graph_min_confidence), step=0.05)

    if up and st.button("Ingest into Graph", type="primary"):
        text = up.read().decode("utf-8", errors="ignore")
        neo = Neo4jClient(uri=neo4j_uri, user=neo4j_user, password=neo4j_password, database=neo4j_db)
        setup_neo4j_indexes(neo)
        store = GraphStore(neo)
        with st.status("Ingesting...", expanded=True) as status:
            st.write("Chunking & saving text...")
            res = ingest_document(doc_id, text, store, min_confidence=min_conf, chunk_size=chunk_size, chunk_overlap=overlap)
            st.write(res)
            status.update(label="Done!", state="complete", expanded=False)
        neo.close()

with tab_query:
    st.subheader("Ask a question")
    query = st.text_input("Your question", value="What is the relationship between machine learning and neural networks?")
    max_hops = st.slider("Max hops", 0, 4, 2)
    if st.button("Search & Answer", type="primary"):
        neo = Neo4jClient()
        llm = LLMClient()
        ent = understand_query(query, llm)
        st.write({"entities": ent})
        results = graph_search(ent, neo, max_hops=max_hops)
        st.write({"results": results})
        answer = generate_answer(query, results, llm)
        st.markdown("### Answer")
        st.write(answer)
        neo.close()

st.caption("© Graph RAG Streamlit example")
